import { requestJson } from "./requestCore";

const TERMINAL_STATUSES = new Set(["SUCCEEDED", "FAILED"]);

function sleep(ms) {
  return new Promise((resolve) => {
    window.setTimeout(resolve, ms);
  });
}

function resolveAcceptedJobId(payload) {
  const jobId = String(payload?.job_id || "").trim();
  if (!jobId) {
    throw new Error("Command response does not include job_id.");
  }
  return jobId;
}

function resolveJobRecord(payload) {
  if (!payload || typeof payload !== "object" || typeof payload.item !== "object" || payload.item === null) {
    throw new Error("Job response is invalid.");
  }
  return payload.item;
}

async function pollJobUntilFinished(jobId, authMode, options = {}) {
  const intervalMs = Number(options.intervalMs) > 0 ? Number(options.intervalMs) : 1500;
  const maxAttempts = Number(options.maxAttempts) > 0 ? Number(options.maxAttempts) : 120;

  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    const payload = await requestJson(`/api/jobs/${encodeURIComponent(jobId)}`, {
      method: "GET",
      authMode,
    });
    const job = resolveJobRecord(payload);

    if (TERMINAL_STATUSES.has(String(job.status || "").trim().toUpperCase())) {
      if (String(job.status || "").trim().toUpperCase() === "FAILED") {
        throw new Error(job.error_message || "Job execution failed.");
      }
      return job;
    }

    if (attempt < maxAttempts) {
      await sleep(intervalMs);
    }
  }

  throw new Error("Job polling timed out before completion.");
}

export async function requestCommandAndTrackJob(path, options = {}) {
  const { method = "POST", body, authMode = "contract", intervalMs, maxAttempts } = options;
  const accepted = await requestJson(path, {
    method,
    body,
    authMode,
  });
  const jobId = resolveAcceptedJobId(accepted);
  const finalJob = await pollJobUntilFinished(jobId, authMode, {
    intervalMs,
    maxAttempts,
  });
  return finalJob.result ?? {};
}
