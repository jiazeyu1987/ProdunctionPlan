import { useEffect, useState } from "react";

export function useServerListResource(loader, deps = []) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError("");
    loader()
      .then((result) => {
        if (cancelled) {
          return;
        }
        setItems(Array.isArray(result?.items) ? result.items : []);
      })
      .catch((err) => {
        if (cancelled) {
          return;
        }
        setError(err?.message || "加载失败");
      })
      .finally(() => {
        if (!cancelled) {
          setLoading(false);
        }
      });
    return () => {
      cancelled = true;
    };
  }, deps);

  return { items, loading, error, setItems, setError };
}
