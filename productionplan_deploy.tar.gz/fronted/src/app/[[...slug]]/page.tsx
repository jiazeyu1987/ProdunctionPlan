﻿"use client";

import dynamic from "next/dynamic";

const LegacyAppPage = dynamic(
  () => import("@/components/legacy-app-page").then((mod) => mod.LegacyAppPage),
  { ssr: false },
);

export default function CatchAllPage() {
  return <LegacyAppPage />;
}
