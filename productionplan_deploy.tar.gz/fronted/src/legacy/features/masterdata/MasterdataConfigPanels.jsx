import DeviceTopologyPanel from "./DeviceTopologyPanel";

export default function MasterdataConfigPanels({
  showPanels,
  saveMessage,
  saveError,
  deviceTopologyProps,
}) {
  if (!showPanels) {
    return null;
  }

  return (
    <>
      {saveMessage ? <p className="notice">{saveMessage}</p> : null}
      {saveError ? <p className="error">{saveError}</p> : null}
      <DeviceTopologyPanel {...deviceTopologyProps} />
    </>
  );
}
