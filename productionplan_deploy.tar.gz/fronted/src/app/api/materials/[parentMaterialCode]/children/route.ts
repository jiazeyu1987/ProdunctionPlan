import { forwardToBackend } from "@/app/api/_shared/backend-proxy";

export async function GET(
  request: Request,
  context: { params: Promise<{ parentMaterialCode: string }> },
) {
  const { parentMaterialCode } = await context.params;
  return forwardToBackend(
    request,
    `/api/materials/${parentMaterialCode}/children`,
  );
}
