import { postContractAndTrackJob } from "../../services/api";

export function saveMasterdataConfig(payload) {
  return postContractAndTrackJob("/api/masterdata/config", payload);
}

export function saveScheduleCalendarRules(payload) {
  return postContractAndTrackJob("/api/masterdata/calendar-rules", payload);
}

export function createMasterdataRoute(payload) {
  return postContractAndTrackJob("/api/masterdata/process-routes/create", payload);
}

export function updateMasterdataRoute(payload) {
  return postContractAndTrackJob("/api/masterdata/process-routes/update", payload);
}

export function copyMasterdataRoute(payload) {
  return postContractAndTrackJob("/api/masterdata/process-routes/copy", payload);
}

export function deleteMasterdataRoute(payload) {
  return postContractAndTrackJob("/api/masterdata/process-routes/delete", payload);
}
