import { contractCommand, contractGet, contractPost } from "../shared/api/contractClient";
import { downloadContractFile as downloadContractFileImpl } from "../shared/api/fileClient";
import { requestJson } from "../shared/api/requestCore";

export function apiRequest(path, options = {}) {
  const { contract = true, ...rest } = options;
  if (contract) {
    return requestJson(path, { ...rest, authMode: "contract" });
  }
  return requestJson(path, { ...rest, authMode: "none" });
}

export function loadList(path) {
  return contractGet(path);
}

export function postContract(path, body) {
  return contractPost(path, body);
}

export function postContractAndTrackJob(path, body) {
  return contractCommand(path, { method: "POST", body });
}

export function contractCommandRequest(path, options = {}) {
  return contractCommand(path, options);
}

export function downloadContractFile(path, fallbackFileName) {
  return downloadContractFileImpl(path, fallbackFileName);
}
