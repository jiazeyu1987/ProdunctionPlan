import { loadList } from "../../services/api";

export function listScheduleVersions() {
  return loadList("/api/schedules");
}

export function getScheduleVersionSnapshot(versionNo) {
  return loadList(`/api/schedules/${encodeURIComponent(versionNo)}`);
}

export function listScheduleVersionTasks(versionNo) {
  return loadList(`/api/schedules/${encodeURIComponent(versionNo)}/tasks`);
}

export function listScheduleVersionAlgorithm(versionNo) {
  return loadList(`/api/schedules/${encodeURIComponent(versionNo)}/algorithm`);
}

export function listScheduleVersionDiff(versionNo, compareWith) {
  return loadList(
    `/api/schedules/${encodeURIComponent(versionNo)}/diff?compare_with=${encodeURIComponent(compareWith)}`,
  );
}

export function listOrderPool() {
  return loadList("/api/order-pool");
}

export function listScheduleVersionDailyProcessLoad(versionNo) {
  return loadList(`/api/schedules/${encodeURIComponent(versionNo)}/process-load/daily`);
}

export function getMasterdataConfig() {
  return loadList("/api/masterdata/config");
}

export function getScheduleCalendarRules() {
  return loadList("/api/masterdata/calendar-rules");
}
