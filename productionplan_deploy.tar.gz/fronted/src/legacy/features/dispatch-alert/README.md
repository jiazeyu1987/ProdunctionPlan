﻿# dispatch-alert feature

Owns alert, dispatch-command, audit, and simulation API access.

1. `queryClient.js`: alert, command, audit, schedule-task, and simulation reads.
2. `commandClient.js`: dispatch, alert, and simulation write operations.
3. `index.js`: feature root export used by pages and controllers.

Recommended imports:

1. Prefer importing from `../dispatch-alert`.
2. Use `queryClient.js` and `commandClient.js` directly in focused tests.
