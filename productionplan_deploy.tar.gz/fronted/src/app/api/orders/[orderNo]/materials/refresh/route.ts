import { forwardToBackend } from "@/app/api/_shared/backend-proxy";

export async function POST(
  request: Request,
  context: { params: Promise<{ orderNo: string }> },
) {
  const { orderNo } = await context.params;
  return forwardToBackend(request, `/api/orders/${orderNo}/materials/refresh`);
}
