import { toChineseError } from "../../utils/i18n";

const CONTRACT_TOKEN = "Bearer mvp-dev-token";
const BACKEND_BASE_URL = process.env.NEXT_PUBLIC_BACKEND_BASE_URL;

function makeRequestId() {
  return `web-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function resolveAuthHeaders(authMode) {
  return authMode === "contract" ? { Authorization: CONTRACT_TOKEN } : {};
}

function buildJsonPayload(method, body) {
  if (method === "GET" || method === "HEAD") {
    return undefined;
  }
  return {
    ...(body ?? {}),
    request_id: body?.request_id || makeRequestId(),
  };
}

function buildRequestUrl(path) {
  if (!BACKEND_BASE_URL) {
    throw new Error("NEXT_PUBLIC_BACKEND_BASE_URL is not configured.");
  }
  return new URL(path, `${BACKEND_BASE_URL.replace(/\/$/, "")}/`).toString();
}

async function parseJsonResponse(response) {
  const text = await response.text();
  const payload = text ? JSON.parse(text) : null;
  if (!response.ok) {
    const error = new Error(
      payload && typeof payload.message === "string"
        ? payload.message
        : `Request failed with status ${response.status}.`,
    );
    error.status = response.status;
    throw error;
  }
  return payload;
}

export async function requestJson(path, options = {}) {
  const { method = "GET", body, authMode = "contract" } = options;
  const payload = buildJsonPayload(method, body);
  const headers = {
    Accept: "application/json",
    ...resolveAuthHeaders(authMode),
  };
  if (payload !== undefined) {
    headers["Content-Type"] = "application/json";
  }

  try {
    const response = await fetch(buildRequestUrl(path), {
      method,
      headers,
      body: payload === undefined ? undefined : JSON.stringify(payload),
      cache: "no-store",
    });
    return await parseJsonResponse(response);
  } catch (error) {
    throw new Error(toChineseError(error?.message, error?.status));
  }
}

export async function requestBlob(path, options = {}) {
  const { method = "GET", authMode = "contract" } = options;

  try {
    const response = await fetch(buildRequestUrl(path), {
      method,
      headers: {
        Accept: "*/*",
        ...resolveAuthHeaders(authMode),
      },
      cache: "no-store",
    });
    if (!response.ok) {
      const error = new Error(`Request failed with status ${response.status}.`);
      error.status = response.status;
      throw error;
    }
    return response;
  } catch (error) {
    throw new Error(toChineseError(error?.message, error?.status));
  }
}
