﻿# schedule feature

Owns schedule read/write clients and shared schedule utilities.

1. `queryClient.js`: unified schedule read endpoints.
2. `commandClient.js`: schedule write operations and legacy generate entry.
3. `topologyScheduleUtils.js`: shared schedule topology helpers.
4. `index.js`: feature root export.

Recommended imports:

1. Prefer importing from `../schedule`.
2. Use `queryClient.js` and `commandClient.js` directly in focused tests.
