import { formatDateTimeByField } from "../utils/datetime";

export default function SimpleTable({
  columns,
  rows,
  className = "",
  rowKey,
  rowClassName,
}) {
  function resolveRowKey(row, index) {
    if (typeof rowKey === "function") {
      return rowKey(row, index);
    }
    if (typeof rowKey === "string" && row[rowKey] !== undefined && row[rowKey] !== null) {
      return row[rowKey];
    }
    if (row.id !== undefined && row.id !== null) {
      return row.id;
    }
    if (row.request_id !== undefined && row.request_id !== null) {
      return row.request_id;
    }
    if (row.report_id !== undefined && row.report_id !== null) {
      return row.report_id;
    }
    if (row.order_no !== undefined && row.order_no !== null) {
      return `${row.order_no}-${index}`;
    }
    return `${index}`;
  }

  return (
    <div className={`table-wrap ${className}`.trim()}>
      <table>
        <thead>
          <tr>
            {columns.map((column, index) => (
              <th key={`${column.key ?? "column"}-${index}`}>{column.title}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr>
              <td colSpan={columns.length}>暂无数据</td>
            </tr>
          ) : (
            rows.map((row, index) => (
              <tr
                key={resolveRowKey(row, index)}
                className={typeof rowClassName === "function" ? rowClassName(row, index) : ""}
              >
                {columns.map((column, columnIndex) => (
                  <td key={`${column.key ?? "column"}-${columnIndex}`}>
                    {column.render
                      ? column.render(row[column.key], row)
                      : String(formatDateTimeByField(row[column.key], column.key) ?? "-")}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
