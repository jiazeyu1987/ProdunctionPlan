"""Pydantic schema package."""
