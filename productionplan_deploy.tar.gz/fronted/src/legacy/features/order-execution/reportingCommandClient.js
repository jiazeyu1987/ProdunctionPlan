import { contractCommandRequest, postContractAndTrackJob } from "../../services/api";

export function createReporting(payload) {
  return postContractAndTrackJob("/api/reportings", payload);
}

export function deleteReporting(reportId) {
  return contractCommandRequest(`/api/reportings/${encodeURIComponent(reportId)}`, {
    method: "DELETE",
    body: {},
  });
}
