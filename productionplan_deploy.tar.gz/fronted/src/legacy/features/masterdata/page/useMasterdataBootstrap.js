import { useCallback, useEffect, useState } from "react";
import { fetchMasterdataBootstrap } from "../service";

export function useMasterdataBootstrap() {
  const [routes, setRoutes] = useState([]);
  const [configRes, setConfigRes] = useState(null);
  const [bootstrapError, setBootstrapError] = useState("");

  const refreshMasterdata = useCallback(async () => {
    setBootstrapError("");
    const snapshot = await fetchMasterdataBootstrap();
    setRoutes(snapshot.routes ?? []);
    setConfigRes(snapshot.configRes ?? null);
  }, []);

  useEffect(() => {
    refreshMasterdata().catch((error) => {
      setBootstrapError(error?.message || "Failed to load masterdata.");
      throw error;
    });
  }, [refreshMasterdata]);

  return {
    routes,
    configRes,
    bootstrapError,
    refreshMasterdata,
  };
}
