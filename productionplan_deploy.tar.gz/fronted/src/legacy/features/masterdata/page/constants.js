export const ROUTE_TAB = "route";
export const EQUIPMENT_TAB = "equipment";
export const DEVICE_CONFIG_TAB = "device_config";
export const CONFIG_SUB_TOPOLOGY = "topology";

export const ROUTE_EDITOR_CREATE = "create";
export const ROUTE_EDITOR_EDIT = "edit";
export const ROUTE_EDITOR_COPY = "copy";

export const ROUTE_PRODUCT_NAME_BY_CODE = Object.freeze({
  "A006.034.10191": "涓€娆℃€т娇鐢ㄩ€犲奖瀵肩 Multipurpose-A1 5F",
  "YXN.009.020.1047": "涓€娆℃€т娇鐢ㄩ€犲奖瀵肩Simmons3 5F",
  "YXN.044.02.1028": "浜叉按娑傚眰閫犲奖瀵肩 HAC-MPA1-06125",
  "YXN.067.005.1006": "浜叉按娑傚眰琛€绠￠€犲奖瀵肩 HVAC5F125-Simmons2",
  "A006.034.6104": "涓€娆℃€т娇鐢ㄩ€犲奖瀵肩 5F C0BRA2",
});

export const HIDDEN_ROUTE_PRODUCT_CODES = new Set([
  "PROD_ANGIO_CATH",
  "PROD_BALLOON",
  "PROD_CATH",
  "PROD_STENT",
]);
