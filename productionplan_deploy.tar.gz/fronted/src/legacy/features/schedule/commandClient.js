import { postContractAndTrackJob } from "../../services/api";

export function generateSchedule(payload) {
  return postContractAndTrackJob("/api/schedules/generate", payload);
}

export function publishScheduleVersion(versionNo, payload) {
  return postContractAndTrackJob(
    `/api/schedules/${encodeURIComponent(versionNo)}/publish`,
    payload,
  );
}

export function saveScheduleCalendarRules(payload) {
  return postContractAndTrackJob("/api/masterdata/calendar-rules", payload);
}
