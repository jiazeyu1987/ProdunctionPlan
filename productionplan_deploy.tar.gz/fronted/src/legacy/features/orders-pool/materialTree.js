function hasOwn(target, key) {
  return Object.prototype.hasOwnProperty.call(target, key);
}

function normalizeMaterialCode(value) {
  return String(value || "").trim();
}

function toFiniteNumber(value) {
  if (typeof value === "number") {
    return Number.isFinite(value) ? value : null;
  }
  if (typeof value === "string") {
    const normalized = value.trim();
    if (!normalized) {
      return null;
    }
    const parsed = Number(normalized);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}

function resolveDisplayIssueQty(row, parentDisplayIssueQty, depth) {
  if (depth <= 0) {
    return toFiniteNumber(row?.issue_qty);
  }
  const numerator = toFiniteNumber(row?.usage_numerator);
  const denominator = toFiniteNumber(row?.usage_denominator);
  if (
    parentDisplayIssueQty === null ||
    parentDisplayIssueQty === undefined ||
    numerator === null ||
    denominator === null ||
    denominator === 0
  ) {
    return null;
  }
  return Math.ceil((parentDisplayIssueQty / denominator) * numerator);
}

function isSelfMadeMaterial(row) {
  const type = String(
    row?.child_material_supply_type || row?.supply_type_code || "",
  ).toUpperCase();
  return type === "SELF_MADE";
}

function collectSelfMadeCodes(rows) {
  if (!Array.isArray(rows)) {
    return [];
  }
  return rows
    .filter((row) => isSelfMadeMaterial(row))
    .map((row) => normalizeMaterialCode(row?.child_material_code))
    .filter(Boolean);
}

function buildMaterialTreeRows(
  rootRows,
  childrenByParentCode,
  expandedNodeKeySet,
  loadingByParentCode,
  errorByParentCode,
) {
  const flattened = [];
  function walk(rows, parentNodeKey, depth, parentDisplayIssueQty = null) {
    if (!Array.isArray(rows)) {
      return;
    }
    rows.forEach((row, index) => {
      const materialCode = normalizeMaterialCode(row?.child_material_code);
      const nodeCode = materialCode || "EMPTY";
      const nodeKey = parentNodeKey
        ? `${parentNodeKey}>${nodeCode}:${index}`
        : `${nodeCode}:${index}`;
      const expandable = isSelfMadeMaterial(row) && Boolean(materialCode);
      const expanded = expandable && expandedNodeKeySet.has(nodeKey);
      const loading = expandable && Boolean(loadingByParentCode[materialCode]);
      const nodeError = expandable ? String(errorByParentCode[materialCode] || "").trim() : "";
      const displayIssueQty = resolveDisplayIssueQty(row, parentDisplayIssueQty, depth);
      flattened.push({
        ...row,
        id: `material-${nodeKey}`,
        _treeDisplayIssueQty: displayIssueQty,
        _treeDepth: depth,
        _treeNodeKey: nodeKey,
        _treeMaterialCode: materialCode,
        _treeExpandable: expandable,
        _treeExpanded: expanded,
        _treeLoading: loading,
        _treeError: nodeError,
      });
      if (expanded) {
        walk(childrenByParentCode[materialCode] ?? [], nodeKey, depth + 1, displayIssueQty);
      }
    });
  }
  walk(rootRows, "", 0, null);
  return flattened;
}

function collapseExpandedMaterialNodeKeys(previousKeys, nodeKey) {
  if (!nodeKey) {
    return previousKeys;
  }
  return (previousKeys || []).filter(
    (key) => key !== nodeKey && !String(key || "").startsWith(`${nodeKey}>`),
  );
}

export {
  buildMaterialTreeRows,
  collectSelfMadeCodes,
  collapseExpandedMaterialNodeKeys,
  hasOwn,
  isSelfMadeMaterial,
  normalizeMaterialCode,
};
