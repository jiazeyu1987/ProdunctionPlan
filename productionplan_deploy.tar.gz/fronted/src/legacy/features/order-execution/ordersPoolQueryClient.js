import { loadList } from "../../services/api";

export function listOrderPool() {
  return loadList("/api/order-pool");
}

export function getOrderPoolItem(orderNo) {
  return loadList(`/api/order-pool/${encodeURIComponent(orderNo)}`);
}

export function listScheduleVersions() {
  return loadList("/api/schedules");
}

export function listMesReportings() {
  return loadList("/api/reportings");
}

export function listScheduleVersionTasks(versionNo) {
  return loadList(`/api/schedules/${encodeURIComponent(versionNo)}/tasks`);
}

export function listOrderPoolMaterials(orderNo, refresh = false) {
  const suffix = refresh ? "?refresh=true" : "";
  return loadList(`/api/order-pool/${encodeURIComponent(orderNo)}/materials${suffix}`);
}

export function listMaterialChildrenByParentCode(parentMaterialCode, refresh = false) {
  const suffix = refresh ? "?refresh=true" : "";
  return loadList(
    `/api/order-pool/materials/${encodeURIComponent(parentMaterialCode)}/children${suffix}`,
  );
}
