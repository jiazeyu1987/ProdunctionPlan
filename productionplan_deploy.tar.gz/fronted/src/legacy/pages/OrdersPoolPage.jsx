import OrdersPoolOrderDetailPanel from "../features/orders-pool/page/OrdersPoolOrderDetailPanel";
import OrdersPoolOrdersTable from "../features/orders-pool/page/OrdersPoolOrdersTable";
import OrdersPoolToolbar from "../features/orders-pool/page/OrdersPoolToolbar";
import { useOrdersPoolPageController } from "../features/orders-pool/page/useOrdersPoolPageController";

export default function OrdersPoolPage() {
  const controller = useOrdersPoolPageController();
  const totalCount = controller.allRows?.length ?? 0;
  const filteredCount = controller.filteredRows?.length ?? 0;
  const hasSelectedOrder = Boolean(controller.selectedOrder);

  const ordersTable = (
    <OrdersPoolOrdersTable
      rows={controller.filteredRows}
      submitting={controller.submitting}
      onCreateCommand={(orderNo, commandType) => controller.createCommand(orderNo, commandType)}
      onDeleteOrder={(orderNo) => controller.deleteOrder(orderNo)}
      onMarkCompleted={(orderNo, row) => controller.markCompleted(orderNo, row)}
    />
  );

  return (
    <section>
      {!hasSelectedOrder ? <h2>生产订单</h2> : null}
      {!hasSelectedOrder ? (
        <OrdersPoolToolbar
          submitting={controller.submitting}
          onRefresh={() => controller.refresh().catch(() => {})}
          productKeyword={controller.productKeyword}
          onProductKeywordChange={controller.setProductKeyword}
          orderStatusFilter={controller.orderStatusFilter}
          onOrderStatusFilterChange={controller.setOrderStatusFilter}
        />
      ) : null}
      {controller.error ? <p className="error">{controller.error}</p> : null}
      {!controller.error && totalCount > 0 && filteredCount === 0 ? (
        <p className="notice">当前筛选条件无匹配，请清空“产品编码 / 名称过滤”或将“状态筛选”切换为“全部状态”。</p>
      ) : null}

      {hasSelectedOrder ? (
        <>
          <div className="toolbar">
            <button type="button" onClick={() => controller.clearOrderNoFilter()}>
              返回订单列表
            </button>
          </div>
          {ordersTable}
        </>
      ) : null}

      <OrdersPoolOrderDetailPanel
        selectedOrder={controller.selectedOrder}
        selectedOrderNo={controller.selectedOrderNo}
        selectedOrderIsScheduled={controller.selectedOrderIsScheduled}
        selectedOrderInProgress={controller.selectedOrderInProgress}
        expectedStartDraft={controller.expectedStartDraft}
        onExpectedStartDraftChange={controller.setExpectedStartDraft}
        submitting={controller.submitting}
        onSaveExpectedStartTime={() => controller.saveExpectedStartTime().catch(() => {})}
        finishedSummary={controller.finishedSummary}
        materialsLoading={controller.materialsLoading}
        materialsRefreshing={controller.materialsRefreshing}
        selfMadeRefreshing={controller.selfMadeRefreshing}
        inventoryRefreshing={controller.inventoryRefreshing}
        materialsError={controller.materialsError}
        materialsRefreshWarning={controller.materialsRefreshWarning}
        materialTreeRows={controller.materialTreeRows}
        onRefreshMaterialsFromErp={() => controller.refreshMaterialsFromErp().catch(() => {})}
        onRefreshSelfMadeFromErp={() => controller.refreshSelfMadeMaterialsFromErp().catch(() => {})}
        onRefreshInventoryFromErp={() => controller.refreshInventoryFromErp().catch(() => {})}
        onToggleMaterialNode={(row) => controller.toggleMaterialNode(row).catch(() => {})}
        selectedOrderReportings={controller.selectedOrderReportings}
        selectedOrderProcessContexts={controller.selectedOrderProcessContexts}
      />
      {controller.orderNoFilter && !controller.selectedOrder ? (
        <p className="error">未找到该生产订单，请检查生产订单号。</p>
      ) : null}

      {!hasSelectedOrder ? ordersTable : null}
    </section>
  );
}
