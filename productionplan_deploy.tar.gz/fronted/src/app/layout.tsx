import type { Metadata } from "next";
import "./globals.css";
import "../legacy/styles/base.css";
import "../legacy/styles/layout.css";
import "../legacy/styles/toolbar.css";
import "../legacy/styles/forms.css";
import "../legacy/styles/tables.css";
import "../legacy/styles/components.css";
import "../legacy/styles/pages/lite-scheduler.css";
import "../legacy/styles/pages/schedule-calendar.css";
import "../legacy/styles/pages/masterdata-topology.css";
import "../legacy/styles/theme-wechat.css";
import "../legacy/styles/responsive.css";

export const metadata: Metadata = {
  title: "ProductionPlan MVP",
  description: "React + Next.js + Mock API frontend for ProductionPlan MVP",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body>{children}</body>
    </html>
  );
}
