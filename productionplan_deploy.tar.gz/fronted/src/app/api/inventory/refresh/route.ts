import { forwardToBackend } from "@/app/api/_shared/backend-proxy";

export async function POST(request: Request) {
  return forwardToBackend(request, "/api/inventory/refresh");
}
