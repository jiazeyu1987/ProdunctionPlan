import { useEffect, useMemo, useState } from "react";
import {
  buildMasterdataConfigSavePayload,
  buildProcessNameByCode,
  buildProcessOptions,
  parseConfigResponse,
  saveMasterdataConfig,
} from "..";
import { useMasterdataDeviceTopologyController } from "./useMasterdataDeviceTopologyController";
import {
  CONFIG_SUB_TOPOLOGY,
  DEVICE_CONFIG_TAB,
  EQUIPMENT_TAB,
  ROUTE_TAB,
} from "./constants";

const DEFAULT_CONFIG_DATA = Object.freeze({
  processConfigs: [],
  lineTopology: [],
});

export function useMasterdataConfigPanelsController({
  routes,
  configRes,
  tabParam,
  configSubParam,
  topologyCompanyParam,
  topologyWorkshopParam,
  topologyLineParam,
  processCodeFilter,
  productCodeFilter,
}) {
  const [activeTab, setActiveTab] = useState(ROUTE_TAB);
  const [configData, setConfigData] = useState({ ...DEFAULT_CONFIG_DATA });
  const [saving, setSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState("");
  const [saveError, setSaveError] = useState("");

  useEffect(() => {
    if (processCodeFilter || productCodeFilter) {
      setActiveTab(ROUTE_TAB);
    }
  }, [processCodeFilter, productCodeFilter]);

  useEffect(() => {
    if (configSubParam === CONFIG_SUB_TOPOLOGY || configSubParam === "process") {
      setActiveTab(DEVICE_CONFIG_TAB);
      return;
    }
    if (tabParam === DEVICE_CONFIG_TAB || tabParam === EQUIPMENT_TAB) {
      setActiveTab(DEVICE_CONFIG_TAB);
      return;
    }
    setActiveTab(ROUTE_TAB);
  }, [tabParam, configSubParam]);

  const processOptions = useMemo(
    () => buildProcessOptions(routes, configData.lineTopology),
    [routes, configData.lineTopology],
  );
  const processNameByCode = useMemo(() => buildProcessNameByCode(processOptions), [processOptions]);

  useEffect(() => {
    if (!configRes) {
      return;
    }
    setConfigData(parseConfigResponse(configRes));
  }, [configRes]);

  async function saveConfig() {
    setSaveMessage("");
    setSaveError("");
    setSaving(true);
    try {
      const payload = buildMasterdataConfigSavePayload(configData.lineTopology, processOptions);
      const res = await saveMasterdataConfig(payload);
      setConfigData(parseConfigResponse(res));
      setSaveMessage("设备拓扑已保存。");
    } catch (error) {
      setSaveError(error.message || "Failed to save topology.");
    } finally {
      setSaving(false);
    }
  }

  const topologyController = useMasterdataDeviceTopologyController({
    enabled: activeTab === DEVICE_CONFIG_TAB,
    configData,
    setConfigData,
    processOptions,
    processNameByCode,
    saving,
    saveConfig,
    topologyCompanyParam,
    topologyWorkshopParam,
    topologyLineParam,
    setSaveError,
  });

  return {
    activeTab,
    setActiveTab,
    saveMessage,
    saveError,
    deviceTopologyProps: topologyController.deviceTopologyProps,
    lineTopology: topologyController.lineTopology,
  };
}
