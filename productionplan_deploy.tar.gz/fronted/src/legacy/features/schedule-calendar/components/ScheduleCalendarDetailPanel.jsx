import { useState } from "react";
import { DATE_SHIFT_MODE } from "../../schedule/calendarModeUtils";
import {
  buildMasterdataTopologyHref,
  formatCompactQty,
  resolveTaskBorderClass,
  shiftName
} from "../scheduleCalendarPageUtils";

const SHIFT_DAY = "DAY";
const SHIFT_NIGHT = "NIGHT";
const LOAD_EPSILON = 0.0001;
const DETAIL_TAB_SCHEDULE = "schedule";
const DETAIL_TAB_MATERIAL = "material";

function normalizeShift(value) {
  const normalized = String(value || "").trim().toUpperCase();
  if (normalized === "D") {
    return SHIFT_DAY;
  }
  if (normalized === "N") {
    return SHIFT_NIGHT;
  }
  return normalized;
}

function requiredShiftsForMode(mode) {
  if (mode === DATE_SHIFT_MODE.DAY) {
    return [SHIFT_DAY];
  }
  if (mode === DATE_SHIFT_MODE.NIGHT) {
    return [SHIFT_NIGHT];
  }
  if (mode === DATE_SHIFT_MODE.BOTH) {
    return [SHIFT_DAY, SHIFT_NIGHT];
  }
  return [];
}

function lineLoadState(items, selectedDateMode) {
  const lineItems = Array.isArray(items) ? items : [];
  if (lineItems.length === 0) {
    return "idle";
  }
  const requiredShifts = requiredShiftsForMode(selectedDateMode);
  if (requiredShifts.length === 0) {
    return "running";
  }
  const shiftLoadMap = new Map();
  for (const item of lineItems) {
    const shiftCode = normalizeShift(item?.shiftCode);
    const plannedQty = Number(item?.planQty || 0) || 0;
    const processCode = String(item?.processCode || "").trim().toUpperCase();
    const capacityPerShift = Number(item?.lineProcessCapacityByCode?.[processCode] || 0) || 0;
    const current = shiftLoadMap.get(shiftCode) || { plannedQty: 0, capacityPerShift: 0 };
    shiftLoadMap.set(shiftCode, {
      plannedQty: current.plannedQty + plannedQty,
      capacityPerShift: Math.max(current.capacityPerShift, capacityPerShift)
    });
  }
  const isFull = requiredShifts.every((shiftCode) => {
    const shiftLoad = shiftLoadMap.get(shiftCode);
    if (!shiftLoad || shiftLoad.capacityPerShift <= LOAD_EPSILON) {
      return false;
    }
    return shiftLoad.plannedQty + LOAD_EPSILON >= shiftLoad.capacityPerShift;
  });
  return isFull ? "full" : "running";
}

function materialQtyText(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) {
    return "-";
  }
  if (Math.abs(n) >= 1000) {
    return formatCompactQty(n);
  }
  if (Math.abs(n - Math.round(n)) < 0.001) {
    return String(Math.round(n));
  }
  return n.toFixed(2);
}

function renderScheduleTab({
  selectedDate,
  selectedDateMode,
  selectedDaySchedule,
  workshopTabs,
  activeWorkshop,
  onSelectWorkshop
}) {
  return (
    <>
      {selectedDateMode === DATE_SHIFT_MODE.REST && selectedDaySchedule?.taskCount > 0 ? (
        <p className="schedule-calendar-warning">
          当前日期设为休息，但该版本仍有排产任务。若要同步规则，请重新生成排产版本。
        </p>
      ) : null}
      <div className="schedule-calendar-tabs" role="tablist" aria-label="车间标签">
        {workshopTabs.map((workshop) => (
          <button
            key={`tab-${workshop.workshopCode}`}
            type="button"
            role="tab"
            aria-selected={activeWorkshop?.workshopCode === workshop.workshopCode}
            data-testid={`schedule-calendar-tab-${workshop.workshopCode}`}
            className={`schedule-calendar-tab-btn ${
              activeWorkshop?.workshopCode === workshop.workshopCode ? "schedule-calendar-tab-btn-active" : ""
            }`}
            onClick={() => onSelectWorkshop(workshop.workshopCode)}
          >
            {workshop.workshopName}
          </button>
        ))}
      </div>
      <div className="schedule-calendar-workshop-grid">
        {activeWorkshop ? (
          <article
            key={`detail-${selectedDate}-${activeWorkshop.key}`}
            className="schedule-calendar-workshop-card"
            data-testid={`schedule-calendar-workshop-${activeWorkshop.workshopCode}`}
          >
            <h4>{activeWorkshop.workshopName}</h4>
            <p className="hint">
              忙线 {activeWorkshop.busyLineCount}/{activeWorkshop.lines.length} · 任务 {activeWorkshop.taskCount} · 订单{" "}
              {activeWorkshop.orderCount}
            </p>
            <div className="schedule-calendar-line-list">
              {activeWorkshop.lines.map((line) => {
                const lineItems = line.items.map((item) => ({
                  ...item,
                  lineProcessCapacityByCode: line.processCapacityByCode
                }));
                const loadState = lineLoadState(lineItems, selectedDateMode);
                const lineNameClass = `schedule-calendar-line-name-btn ${
                  loadState === "full"
                    ? "schedule-calendar-line-name-btn-full"
                    : loadState === "running"
                      ? "schedule-calendar-line-name-btn-running"
                      : ""
                }`.trim();
                return (
                  <div key={`${selectedDate}-${line.key}`} className="schedule-calendar-line-row">
                    <a
                      className={lineNameClass}
                      data-testid={`schedule-calendar-line-select-${line.workshopCode}-${line.lineCode}`}
                      href={buildMasterdataTopologyHref(line)}
                      title="跳转到主数据-产线拓扑查看并编辑这条产线工艺"
                    >
                      {line.lineName}
                    </a>
                    <div className="schedule-calendar-line-orders">
                      {lineItems.length === 0 ? (
                        <span className="hint">空闲</span>
                      ) : (
                        lineItems.map((item, index) => (
                          <span
                            key={`${line.key}-${item.id}-${index}`}
                            className={`lite-cal-order-chip ${resolveTaskBorderClass(item.orderNo)}`}
                          >
                            <span className="lite-cal-order-main">{item.orderNo}</span>
                            <span className="lite-cal-order-meta">
                              {item.processName} · {shiftName(item.shiftCode)} · 数量:{formatCompactQty(item.planQty)}
                            </span>
                          </span>
                        ))
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
            <p className="hint">点击产线名称将跳转到主数据-产线拓扑进行查看与编辑。</p>
          </article>
        ) : (
          <p className="hint">暂无车间排产信息。</p>
        )}
      </div>
    </>
  );
}

function renderMaterialTab({ selectedDate, materialEstimateRows, loadingMaterialEstimate, materialEstimateError }) {
  if (loadingMaterialEstimate) {
    return <p className="hint">正在加载即时物料明细...</p>;
  }
  if (materialEstimateError) {
    return <p className="error">{materialEstimateError}</p>;
  }
  return (
    <div key={`material-estimate-${selectedDate || "none"}`} className="schedule-calendar-material-card">
      <p className="hint">估算口径：按订单截至所选日期的累计排产进度，折算整单用量占用，用于查看该日期的预估即时库存余额。</p>
      {materialEstimateRows.length === 0 ? (
        <p className="hint">该日期前暂无已开工订单，暂无即时物料消耗。</p>
      ) : (
        <div className="schedule-calendar-material-table-wrap">
          <table className="schedule-calendar-material-table">
            <thead>
              <tr>
                <th>物料编码</th>
                <th>物料名称</th>
                <th>供给方式</th>
                <th>当前库存</th>
                <th>计划占用</th>
                <th>预估即时库存</th>
                <th>涉及订单</th>
              </tr>
            </thead>
            <tbody>
              {materialEstimateRows.map((row) => (
                <tr key={row.materialCode}>
                  <td>{row.materialCode}</td>
                  <td>{row.materialName}</td>
                  <td>{row.supplyTypeName}</td>
                  <td>{materialQtyText(row.inventoryQty)}</td>
                  <td>{materialQtyText(row.plannedConsumeQty)}</td>
                  <td
                    className={
                      row.estimatedQty < 0
                        ? "schedule-calendar-material-negative"
                        : row.estimatedQty <= LOAD_EPSILON
                          ? "schedule-calendar-material-warning"
                          : "schedule-calendar-material-positive"
                    }
                  >
                    {materialQtyText(row.estimatedQty)}
                  </td>
                  <td>{row.orderNos.join("，")}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export function ScheduleCalendarDetailPanel({
  selectedDate,
  selectedDateMode,
  selectedDaySchedule,
  workshopTabs,
  activeWorkshop,
  onSelectWorkshop,
  materialEstimateRows,
  loadingMaterialEstimate,
  materialEstimateError
}) {
  const [activeDetailTab, setActiveDetailTab] = useState(DETAIL_TAB_SCHEDULE);

  return (
    <div className="panel schedule-calendar-detail-panel">
      <div className="panel-head">
        <h3>{selectedDate || "-"} 详情</h3>
      </div>
      <div className="schedule-calendar-detail-switch" role="tablist" aria-label="详情视图切换">
        <button
          type="button"
          role="tab"
          aria-selected={activeDetailTab === DETAIL_TAB_SCHEDULE}
          className={`schedule-calendar-detail-switch-btn ${
            activeDetailTab === DETAIL_TAB_SCHEDULE ? "schedule-calendar-detail-switch-btn-active" : ""
          }`}
          onClick={() => setActiveDetailTab(DETAIL_TAB_SCHEDULE)}
        >
          排产明细
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={activeDetailTab === DETAIL_TAB_MATERIAL}
          className={`schedule-calendar-detail-switch-btn ${
            activeDetailTab === DETAIL_TAB_MATERIAL ? "schedule-calendar-detail-switch-btn-active" : ""
          }`}
          onClick={() => setActiveDetailTab(DETAIL_TAB_MATERIAL)}
        >
          即时物料明细
        </button>
      </div>
      {activeDetailTab === DETAIL_TAB_SCHEDULE
        ? renderScheduleTab({
            selectedDate,
            selectedDateMode,
            selectedDaySchedule,
            workshopTabs,
            activeWorkshop,
            onSelectWorkshop
          })
        : renderMaterialTab({
            selectedDate,
            materialEstimateRows,
            loadingMaterialEstimate,
            materialEstimateError
          })}
    </div>
  );
}
