import { loadList } from "../../services/api";

export function listProcessRoutes() {
  return loadList("/api/masterdata/process-routes");
}

export function getMasterdataConfig() {
  return loadList("/api/masterdata/config");
}

export function getScheduleCalendarRules() {
  return loadList("/api/masterdata/calendar-rules");
}

export function listScheduleVersions() {
  return loadList("/api/schedules");
}
