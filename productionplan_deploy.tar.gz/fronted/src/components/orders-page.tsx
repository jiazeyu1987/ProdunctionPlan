"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { fetchOrders } from "@/lib/api";
import type { OrderStatus, OrderSummary } from "@/lib/types";

const statusOptions: Array<{ label: string; value: "" | OrderStatus }> = [
  { label: "全部", value: "" },
  { label: "计划确认", value: "计划确认" },
  { label: "生产中", value: "生产中" },
  { label: "待发料", value: "待发料" },
  { label: "已完工", value: "已完工" },
];

function getStatusClassName(status: OrderStatus) {
  if (status === "生产中") return "status-pill is-active";
  if (status === "待发料") return "status-pill is-warning";
  if (status === "已完工") return "status-pill is-done";
  return "status-pill";
}

function OrderCard({ order }: { order: OrderSummary }) {
  return (
    <Link className="list-card" href={`/orders/${order.production_order_no}`}>
      <div className="card-topline">
        <span className="order-no">{order.production_order_no}</span>
        <span className={getStatusClassName(order.status)}>{order.status}</span>
      </div>
      <h3 className="card-title">{order.material_name}</h3>
      <p className="card-subtitle">
        {order.material_code}
        <br />
        {order.material_specification}
      </p>
      <div className="metrics-grid">
        <div className="metric-box">
          <div className="metric-label">生产数量</div>
          <div className="metric-value">{order.production_qty}</div>
        </div>
        <div className="metric-box">
          <div className="metric-label">BOM 单号</div>
          <div className="metric-value">{order.material_list_no}</div>
        </div>
      </div>
      <span className="link-ghost">
        查看详情
        <span aria-hidden>›</span>
      </span>
    </Link>
  );
}

export function OrdersPage() {
  const [keyword, setKeyword] = useState("");
  const [status, setStatus] = useState<"" | OrderStatus>("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [orders, setOrders] = useState<OrderSummary[]>([]);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setLoading(true);
      setError("");
      try {
        const result = await fetchOrders({ keyword, status });
        if (!cancelled) {
          setOrders(result.items);
        }
      } catch (fetchError) {
        if (!cancelled) {
          setError(
            fetchError instanceof Error ? fetchError.message : "订单列表加载失败。",
          );
          setOrders([]);
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    load().catch(() => {});

    return () => {
      cancelled = true;
    };
  }, [keyword, status]);

  const summaryText = useMemo(() => {
    if (loading) return "正在同步订单池视图…";
    return `当前展示 ${orders.length} 张生产订单`;
  }, [loading, orders.length]);

  return (
    <main className="mobile-shell">
      <header className="mini-app-header">
        <div className="mini-app-brand">
          <div className="mini-app-badge">计</div>
          <div>
            <h1 className="mini-app-title">生产订单</h1>
            <p className="mini-app-subtitle">ProductionPlan MVP / Mock API</p>
          </div>
        </div>
      </header>

      <section className="hero-card">
        <h2 className="mini-app-title">订单池</h2>
        <p className="mini-app-subtitle">
          微信小程序风格的订单入口，先聚焦订单、清单、报工和产能四个视图。
        </p>
        <div className="hero-chip-row">
          <span className="hero-chip">Next.js App Router</span>
          <span className="hero-chip">React</span>
          <span className="hero-chip">Mock API</span>
          <span className="hero-chip">MVP</span>
        </div>
      </section>

      <section className="search-panel">
        <input
          className="search-input"
          value={keyword}
          onChange={(event) => setKeyword(event.target.value)}
          placeholder="搜索订单号、产品编码、产品名称"
        />
        <div className="chip-group">
          {statusOptions.map((option) => (
            <button
              key={option.label}
              className={`chip-button${status === option.value ? " active" : ""}`}
              type="button"
              onClick={() => setStatus(option.value)}
            >
              {option.label}
            </button>
          ))}
        </div>
      </section>

      <section className="tab-panel">
        <div className="tab-title-row">
          <div>
            <h2 className="tab-title">生产订单列表</h2>
            <p className="tab-desc">{summaryText}</p>
          </div>
        </div>
      </section>

      <section className="section-stack">
        {error ? <p className="error">{error}</p> : null}
        {loading ? <p className="notice">订单加载中…</p> : null}
        {!loading && !error && orders.length === 0 ? (
          <p className="notice">当前筛选条件下没有订单。</p>
        ) : null}
        {!loading && !error ? (
          <div className="orders-list">
            {orders.map((order) => (
              <OrderCard key={order.production_order_no} order={order} />
            ))}
          </div>
        ) : null}
      </section>
    </main>
  );
}
