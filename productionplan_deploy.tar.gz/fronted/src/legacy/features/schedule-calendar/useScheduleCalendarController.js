import { useCallback, useEffect, useMemo, useState } from "react";
import {
  advanceSimulationOneDay as apiAdvanceSimulationOneDay,
  resetManualSimulation as apiResetManualSimulation
} from "../dispatch-alert";
import {
  generateSchedule,
  getMasterdataConfig,
  getScheduleCalendarRules,
  listScheduleVersions,
  listScheduleVersionTasks,
  publishScheduleVersion,
  saveScheduleCalendarRules
} from "../schedule";
import { listOrderPoolMaterials } from "../order-execution/ordersPoolQueryClient";
import {
  buildCalendarWeeksByMonth,
  formatMonthText,
  getMonthDayCount,
  isoTodayLocal,
  monthTextFromDate,
  pad2,
  parseMonthText
} from "../schedule/calendarDateUtils";
import {
  DATE_SHIFT_MODE,
  DATE_SHIFT_MODE_LABEL,
  defaultDateShiftMode,
  nextDateShiftMode,
  normalizeDateShiftMode,
  normalizeDateShiftModeByDate,
  normalizeWeekendRestMode,
  resolveDateShiftMode
} from "../schedule/calendarModeUtils";
import {
  buildDayScheduleMap,
  buildEmptyDaySchedule,
  buildTopology,
  normalizeTaskRows
} from "../schedule/topologyScheduleUtils";
import { isCnStatutoryHoliday, WEEKEND_REST_MODE } from "../../utils/liteSchedulerEngine";
import {
  STRATEGY_OPTIONS,
  normalizeStrategyCode,
  normalizeVersionNo,
  parseCalendarRulesResponse,
  parseMasterdataConfigResponse,
  pickPreferredVersionNo,
  strategyLabel
} from "./scheduleCalendarPageUtils";

export function useScheduleCalendarController() {
  function toNumber(value, fallback = 0) {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
  }

  function normalizeDateText(value) {
    const text = String(value || "").trim();
    return /^\d{4}-\d{2}-\d{2}$/.test(text) ? text : "";
  }

  function addOneDay(dateText) {
    const normalized = normalizeDateText(dateText);
    if (!normalized) {
      return isoTodayLocal();
    }
    const [year, month, day] = normalized.split("-").map((item) => Number(item));
    const date = new Date(year, month - 1, day);
    date.setDate(date.getDate() + 1);
    const nextYear = date.getFullYear();
    const nextMonth = String(date.getMonth() + 1).padStart(2, "0");
    const nextDay = String(date.getDate()).padStart(2, "0");
    return `${nextYear}-${nextMonth}-${nextDay}`;
  }

  function pickText(...values) {
    for (const value of values) {
      const text = String(value || "").trim();
      if (text) {
        return text;
      }
    }
    return "";
  }

  function skipRestDatesFrom(dateText, options) {
    let current = normalizeDateText(dateText);
    if (!current) {
      return isoTodayLocal();
    }
    const { skipHolidays, weekendMode, dateModeByDate } = options;
    for (let guard = 0; guard < 366; guard += 1) {
      const mode = resolveDateShiftMode(
        current,
        skipHolidays === true,
        weekendMode,
        dateModeByDate
      );
      if (mode !== DATE_SHIFT_MODE.REST) {
        return current;
      }
      current = addOneDay(current);
    }
    return current;
  }

  const [versions, setVersions] = useState([]);
  const [selectedVersionNo, setSelectedVersionNo] = useState("");
  const [tasks, setTasks] = useState([]);
  const [lineTopologyRows, setLineTopologyRows] = useState([]);
  const [skipStatutoryHolidays, setSkipStatutoryHolidays] = useState(false);
  const [weekendRestMode, setWeekendRestMode] = useState(WEEKEND_REST_MODE.DOUBLE);
  const [dateShiftModeByDate, setDateShiftModeByDate] = useState({});
  const [calendarMonth, setCalendarMonth] = useState(
    monthTextFromDate(isoTodayLocal()) || "2026-01"
  );
  const [simulatedCurrentDate, setSimulatedCurrentDate] = useState(isoTodayLocal());
  const [selectedDate, setSelectedDate] = useState(isoTodayLocal());
  const [loadingInit, setLoadingInit] = useState(false);
  const [loadingTasks, setLoadingTasks] = useState(false);
  const [savingRules, setSavingRules] = useState(false);
  const [replanning, setReplanning] = useState(false);
  const [generatingDraft, setGeneratingDraft] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [advancingSimulationDay, setAdvancingSimulationDay] = useState(false);
  const [resettingSimulation, setResettingSimulation] = useState(false);
  const [activeWorkshopCode, setActiveWorkshopCode] = useState("");
  const [strategyCode, setStrategyCode] = useState("KEY_ORDER_FIRST");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [loadingMaterialEstimate, setLoadingMaterialEstimate] = useState(false);
  const [materialEstimateError, setMaterialEstimateError] = useState("");
  const [orderMaterialsByOrderNo, setOrderMaterialsByOrderNo] = useState({});

  const topology = useMemo(() => buildTopology(lineTopologyRows, tasks), [lineTopologyRows, tasks]);
  const dayScheduleByDate = useMemo(() => buildDayScheduleMap(tasks, topology), [tasks, topology]);
  const calendarWeeks = useMemo(() => buildCalendarWeeksByMonth(calendarMonth), [calendarMonth]);

  const selectedDaySchedule = useMemo(() => {
    if (!selectedDate) {
      return null;
    }
    return dayScheduleByDate[selectedDate] || buildEmptyDaySchedule(selectedDate, topology.workshops);
  }, [dayScheduleByDate, selectedDate, topology.workshops]);

  const workshopTabs = useMemo(
    () => (Array.isArray(selectedDaySchedule?.workshops) ? selectedDaySchedule.workshops : []),
    [selectedDaySchedule]
  );

  const activeWorkshop = useMemo(() => {
    if (workshopTabs.length === 0) {
      return null;
    }
    return workshopTabs.find((item) => item.workshopCode === activeWorkshopCode) || workshopTabs[0];
  }, [activeWorkshopCode, workshopTabs]);

  const versionOptions = useMemo(
    () =>
      (versions || []).map((row) => ({
        versionNo: normalizeVersionNo(row),
        statusName: String(row?.status_name_cn || row?.status || "").trim() || "-"
      })),
    [versions]
  );

  const selectedVersionRow = useMemo(
    () => (versions || []).find((row) => normalizeVersionNo(row) === selectedVersionNo) || null,
    [selectedVersionNo, versions]
  );

  const canPublishSelected =
    String(selectedVersionRow?.status || "")
      .trim()
      .toUpperCase() === "DRAFT";

  const orderStartDateByOrderNo = useMemo(() => {
    const out = {};
    for (const task of tasks) {
      const orderNo = String(task?.orderNo || "").trim();
      const date = String(task?.date || "").trim();
      if (!orderNo || !date) {
        continue;
      }
      if (!out[orderNo] || date < out[orderNo]) {
        out[orderNo] = date;
      }
    }
    return out;
  }, [tasks]);

  const orderMaterialConsumeRatioByDate = useMemo(() => {
    const out = {};
    const tasksByOrderNo = new Map();
    for (const task of tasks) {
      const orderNo = String(task?.orderNo || "").trim();
      if (!orderNo) {
        continue;
      }
      const list = tasksByOrderNo.get(orderNo) || [];
      list.push(task);
      tasksByOrderNo.set(orderNo, list);
    }
    for (const [orderNo, orderTasks] of tasksByOrderNo.entries()) {
      const sortedTasks = orderTasks.slice().sort((a, b) => {
        if (a.date !== b.date) {
          return String(a.date).localeCompare(String(b.date), "zh-Hans-CN");
        }
        if (a.planStartTime !== b.planStartTime) {
          return String(a.planStartTime).localeCompare(String(b.planStartTime), "zh-Hans-CN");
        }
        return String(a.processCode).localeCompare(String(b.processCode), "zh-Hans-CN");
      });
      if (sortedTasks.length === 0) {
        out[orderNo] = 0;
        continue;
      }
      const totalQty = sortedTasks.reduce((sum, task) => sum + toNumber(task?.planQty, 0), 0);
      if (totalQty <= 0) {
        out[orderNo] = 0;
        continue;
      }
      const cumulativeQty = sortedTasks.reduce((sum, task) => {
        return task.date <= selectedDate ? sum + toNumber(task?.planQty, 0) : sum;
      }, 0);
      out[orderNo] = Math.max(0, Math.min(1, cumulativeQty / totalQty));
    }
    return out;
  }, [selectedDate, tasks]);

  const selectedDateMaterialEstimateRows = useMemo(() => {
    if (!selectedDate) {
      return [];
    }
    const rowsByMaterialCode = new Map();
    for (const [orderNo, startDate] of Object.entries(orderStartDateByOrderNo)) {
      if (!startDate || startDate > selectedDate) {
        continue;
      }
      const consumeRatio = toNumber(orderMaterialConsumeRatioByDate[orderNo], 0);
      if (consumeRatio <= 0) {
        continue;
      }
      const materialRows = Array.isArray(orderMaterialsByOrderNo[orderNo]) ? orderMaterialsByOrderNo[orderNo] : [];
      for (const row of materialRows) {
        const materialCode = String(row?.child_material_code || "").trim().toUpperCase();
        if (!materialCode) {
          continue;
        }
        const current = rowsByMaterialCode.get(materialCode) || {
          materialCode,
          materialName:
            pickText(
              row?.child_material_name_cn,
              row?.child_material_name,
              row?.material_name_cn,
              row?.material_name
            ) || "-",
          supplyTypeName:
            pickText(
              row?.child_material_supply_type_name_cn,
              row?.supply_type_name,
              row?.child_material_supply_type,
              row?.supply_type_code
            ) || "-",
          inventoryQty: toNumber(
            row?.child_material_inventory_qty ?? row?.inventory_qty,
            0
          ),
          plannedConsumeQty: 0,
          estimatedQty: 0,
          orderNos: []
        };
        current.materialName =
          current.materialName === "-"
            ? pickText(
                row?.child_material_name_cn,
                row?.child_material_name,
                row?.material_name_cn,
                row?.material_name
              ) || "-"
            : current.materialName;
        current.supplyTypeName =
          current.supplyTypeName === "-"
            ? pickText(
                row?.child_material_supply_type_name_cn,
                row?.supply_type_name,
                row?.child_material_supply_type,
                row?.supply_type_code
              ) || "-"
            : current.supplyTypeName;
        current.inventoryQty = Math.max(
          current.inventoryQty,
          toNumber(row?.child_material_inventory_qty ?? row?.inventory_qty, 0)
        );
        current.plannedConsumeQty += toNumber(row?.required_qty ?? row?.issue_qty, 0) * consumeRatio;
        if (!current.orderNos.includes(orderNo)) {
          current.orderNos.push(orderNo);
        }
        current.estimatedQty = current.inventoryQty - current.plannedConsumeQty;
        rowsByMaterialCode.set(materialCode, current);
      }
    }
    return [...rowsByMaterialCode.values()].sort((a, b) => {
      if (a.estimatedQty !== b.estimatedQty) {
        return a.estimatedQty - b.estimatedQty;
      }
      return String(a.materialCode).localeCompare(String(b.materialCode), "zh-Hans-CN");
    });
  }, [orderMaterialConsumeRatioByDate, orderMaterialsByOrderNo, orderStartDateByOrderNo, selectedDate]);

  const refreshVersionsAndConfig = useCallback(async (keepCurrentSelection = true) => {
    setLoadingInit(true);
    setError("");
    try {
      const [versionsRes, configRes, rulesRes] = await Promise.all([
        listScheduleVersions(),
        getMasterdataConfig(),
        getScheduleCalendarRules()
      ]);

      const versionRows = Array.isArray(versionsRes?.items) ? versionsRes.items : [];
      setVersions(versionRows);
      setSelectedVersionNo((prev) => {
        if (
          keepCurrentSelection &&
          prev &&
          versionRows.some((row) => normalizeVersionNo(row) === prev)
        ) {
          return prev;
        }
        return pickPreferredVersionNo(versionRows);
      });

      const configData = parseMasterdataConfigResponse(configRes);
      setLineTopologyRows(Array.isArray(configData.lineTopology) ? configData.lineTopology : []);

      const rulesData = parseCalendarRulesResponse(rulesRes);
      setSkipStatutoryHolidays(rulesData.skipStatutoryHolidays === true);
      setWeekendRestMode(normalizeWeekendRestMode(rulesData.weekendRestMode));
      setDateShiftModeByDate(normalizeDateShiftModeByDate(rulesData.dateShiftModeByDate));
    } catch (e) {
      setError(e.message || "加载失败");
    } finally {
      setLoadingInit(false);
    }
  }, []);

  const refreshTasks = useCallback(async (versionNo) => {
    const safeVersionNo = String(versionNo || "").trim();
    if (!safeVersionNo) {
      setTasks([]);
      return;
    }
    setLoadingTasks(true);
    setError("");
    try {
      const result = await listScheduleVersionTasks(safeVersionNo);
      const normalized = normalizeTaskRows(result?.items ?? []);
      setTasks(normalized);
      if (normalized.length > 0) {
        const firstDate = normalized[0].date;
        setCalendarMonth((prev) => prev || monthTextFromDate(firstDate) || monthTextFromDate(isoTodayLocal()));
        setSelectedDate((prev) => prev || firstDate);
      }
    } catch (e) {
      setTasks([]);
      setError(e.message || "加载排产任务失败");
    } finally {
      setLoadingTasks(false);
    }
  }, []);

  useEffect(() => {
    refreshVersionsAndConfig(false).catch((err) => {
      throw err;
    });
  }, [refreshVersionsAndConfig]);

  useEffect(() => {
    refreshTasks(selectedVersionNo).catch((err) => {
      throw err;
    });
  }, [refreshTasks, selectedVersionNo]);

  useEffect(() => {
    let cancelled = false;
    const scheduledOrderNos = [...new Set(tasks.map((row) => String(row?.orderNo || "").trim()).filter(Boolean))];
    if (scheduledOrderNos.length === 0) {
      setOrderMaterialsByOrderNo({});
      setMaterialEstimateError("");
      setLoadingMaterialEstimate(false);
      return () => {
        cancelled = true;
      };
    }
    setLoadingMaterialEstimate(true);
    setMaterialEstimateError("");
    Promise.all(
      scheduledOrderNos.map(async (orderNo) => {
        const result = await listOrderPoolMaterials(orderNo);
        return [orderNo, Array.isArray(result?.items) ? result.items : []];
      })
    )
      .then((materialEntries) => {
        if (cancelled) {
          return;
        }
        setOrderMaterialsByOrderNo(Object.fromEntries(materialEntries));
      })
      .catch((e) => {
        if (cancelled) {
          return;
        }
        setOrderMaterialsByOrderNo({});
        setMaterialEstimateError(e?.message || "加载即时物料明细失败");
      })
      .finally(() => {
        if (!cancelled) {
          setLoadingMaterialEstimate(false);
        }
      });
    return () => {
      cancelled = true;
    };
  }, [tasks]);

  useEffect(() => {
    setStrategyCode(
      normalizeStrategyCode(selectedVersionRow?.strategy_code || selectedVersionRow?.strategyCode)
    );
  }, [selectedVersionRow]);

  useEffect(() => {
    if (!selectedDate) {
      return;
    }
    const parsed = parseMonthText(calendarMonth);
    if (!parsed) {
      return;
    }
    const firstDay = `${parsed.year}-${pad2(parsed.month)}-01`;
    const lastDay = `${parsed.year}-${pad2(parsed.month)}-${pad2(
      getMonthDayCount(parsed.year, parsed.month)
    )}`;
    if (selectedDate < firstDay || selectedDate > lastDay) {
      setSelectedDate(firstDay);
    }
  }, [calendarMonth, selectedDate]);

  useEffect(() => {
    if (workshopTabs.length === 0) {
      setActiveWorkshopCode("");
      return;
    }
    const exists = workshopTabs.some((item) => item.workshopCode === activeWorkshopCode);
    if (!exists) {
      setActiveWorkshopCode(workshopTabs[0].workshopCode);
    }
  }, [activeWorkshopCode, workshopTabs]);

  const moveCalendarMonth = useCallback(
    (offset) => {
      const parsed = parseMonthText(calendarMonth);
      if (!parsed) {
        return;
      }
      const date = new Date(Date.UTC(parsed.year, parsed.month - 1, 1));
      date.setUTCMonth(date.getUTCMonth() + Number(offset || 0));
      setCalendarMonth(formatMonthText(date.getUTCFullYear(), date.getUTCMonth() + 1));
    },
    [calendarMonth]
  );

  const selectCalendarMonth = useCallback((value) => {
    const parsed = parseMonthText(value);
    if (!parsed) {
      return;
    }
    setCalendarMonth(formatMonthText(parsed.year, parsed.month));
  }, []);

  const restReasonForDate = useCallback(
    (dateText) => {
      if (skipStatutoryHolidays === true && isCnStatutoryHoliday(dateText)) {
        return "法定节假日";
      }
      return "";
    },
    [skipStatutoryHolidays]
  );

  const setDateMode = useCallback(
    (dateText, mode) => {
      const safeDate = String(dateText || "").trim();
      if (!safeDate) {
        return;
      }
      const normalizedActionMode = normalizeDateShiftMode(mode);
      if (!normalizedActionMode) {
        return;
      }
      const currentMode = resolveDateShiftMode(
        safeDate,
        skipStatutoryHolidays === true,
        weekendRestMode,
        dateShiftModeByDate
      );
      const normalizedMode = nextDateShiftMode(currentMode, normalizedActionMode);
      const defaultMode = defaultDateShiftMode(
        safeDate,
        skipStatutoryHolidays === true,
        weekendRestMode
      );
      setDateShiftModeByDate((prev) => {
        const next = { ...prev };
        if (!normalizedMode || normalizedMode === defaultMode) {
          delete next[safeDate];
        } else {
          next[safeDate] = normalizedMode;
        }
        return next;
      });
      setMessage(`${safeDate} 已设置为 ${DATE_SHIFT_MODE_LABEL[normalizedMode] || normalizedMode}。`);
      setError("");
    },
    [dateShiftModeByDate, skipStatutoryHolidays, weekendRestMode]
  );

  const saveRules = useCallback(async () => {
    setSavingRules(true);
    setMessage("");
    setError("");
    try {
      const payload = {
        operator: "calendar-admin",
        skip_statutory_holidays: skipStatutoryHolidays === true,
        weekend_rest_mode: normalizeWeekendRestMode(weekendRestMode),
        date_shift_mode_by_date: normalizeDateShiftModeByDate(dateShiftModeByDate)
      };
      await saveScheduleCalendarRules(payload);
      setMessage("排期规则已保存。");
    } catch (e) {
      setError(e.message || "保存失败");
    } finally {
      setSavingRules(false);
    }
  }, [dateShiftModeByDate, skipStatutoryHolidays, weekendRestMode]);

  const saveAndReplan = useCallback(async () => {
    if (!selectedVersionNo) {
      setError("请先选择一个排产版本。");
      setMessage("");
      return;
    }
    setReplanning(true);
    setMessage("");
    setError("");
    try {
      const payload = {
        operator: "calendar-admin",
        skip_statutory_holidays: skipStatutoryHolidays === true,
        weekend_rest_mode: normalizeWeekendRestMode(weekendRestMode),
        date_shift_mode_by_date: normalizeDateShiftModeByDate(dateShiftModeByDate)
      };
      await saveScheduleCalendarRules(payload);
      const generated = await generateSchedule({
        base_version_no: selectedVersionNo,
        autoReplan: false,
        strategy_code: normalizeStrategyCode(
          selectedVersionRow?.strategy_code || selectedVersionRow?.strategyCode
        )
      });
      const nextVersionNo = normalizeVersionNo(generated);
      await refreshVersionsAndConfig(false);
      if (nextVersionNo) {
        setSelectedVersionNo(nextVersionNo);
        await refreshTasks(nextVersionNo);
        setMessage(`已按最新规则重排，生成新版本：${nextVersionNo}`);
      } else {
        setMessage("已触发重排，请刷新版本列表确认新版本号。");
      }
    } catch (e) {
      setError(e.message || "重排失败");
    } finally {
      setReplanning(false);
    }
  }, [
    dateShiftModeByDate,
    refreshTasks,
    refreshVersionsAndConfig,
    selectedVersionNo,
    selectedVersionRow,
    skipStatutoryHolidays,
    weekendRestMode
  ]);

  const generateDraftVersion = useCallback(async () => {
    setGeneratingDraft(true);
    setMessage("");
    setError("");
    try {
      const nextStrategyCode = normalizeStrategyCode(strategyCode);
      const generated = await generateSchedule({
        base_version_no: selectedVersionNo || null,
        autoReplan: false,
        strategy_code: nextStrategyCode
      });
      const nextVersionNo = normalizeVersionNo(generated);
      await refreshVersionsAndConfig(true);
      if (nextVersionNo) {
        setSelectedVersionNo(nextVersionNo);
        setMessage(`已生成草稿版本：${nextVersionNo}（${strategyLabel(nextStrategyCode)}）`);
      } else {
        setMessage("已生成草稿版本，请刷新版本列表确认新版本号。");
      }
    } catch (e) {
      setError(e.message || "生成草稿版本失败");
    } finally {
      setGeneratingDraft(false);
    }
  }, [refreshVersionsAndConfig, selectedVersionNo, strategyCode]);

  const publishSelectedDraft = useCallback(async () => {
    if (!selectedVersionNo) {
      setError("请先选择草稿版本。");
      setMessage("");
      return;
    }
    if (!canPublishSelected) {
      setError("当前选择的版本不是草稿，无法发布。");
      setMessage("");
      return;
    }
    setPublishing(true);
    setMessage("");
    setError("");
    try {
      await publishScheduleVersion(selectedVersionNo, {
        operator: "publisher01",
        reason: "月历排期发布草稿"
      });
      await refreshVersionsAndConfig(true);
      await refreshTasks(selectedVersionNo);
      setMessage(`已发布版本：${selectedVersionNo}`);
    } catch (e) {
      setError(e.message || "发布草稿版本失败");
    } finally {
      setPublishing(false);
    }
  }, [canPublishSelected, refreshTasks, refreshVersionsAndConfig, selectedVersionNo]);

  const advanceSimulationOneDay = useCallback(async () => {
    setAdvancingSimulationDay(true);
    setMessage("");
    setError("");
    try {
      const result = await apiAdvanceSimulationOneDay({
        client_date: isoTodayLocal()
      });
      const returnedDate =
        normalizeDateText(result?.current_date) ||
        normalizeDateText(result?.currentDate) ||
        normalizeDateText(result?.simulation_date) ||
        normalizeDateText(result?.simulationDate);
      setSimulatedCurrentDate((prev) => {
        if (returnedDate) {
          return skipRestDatesFrom(returnedDate, {
            skipHolidays: skipStatutoryHolidays,
            weekendMode: weekendRestMode,
            dateModeByDate: dateShiftModeByDate
          });
        }
        const advanced = addOneDay(prev);
        return skipRestDatesFrom(advanced, {
          skipHolidays: skipStatutoryHolidays,
          weekendMode: weekendRestMode,
          dateModeByDate: dateShiftModeByDate
        });
      });
      if (selectedVersionNo) {
        await refreshTasks(selectedVersionNo);
      }
      setMessage(result?.message || "手动模拟已推进1天。");
    } catch (e) {
      setError(e.message || "推进一天失败");
    } finally {
      setAdvancingSimulationDay(false);
    }
  }, [dateShiftModeByDate, refreshTasks, selectedVersionNo, skipStatutoryHolidays, weekendRestMode]);

  const resetManualSimulation = useCallback(async () => {
    setResettingSimulation(true);
    setMessage("");
    setError("");
    try {
      const result = await apiResetManualSimulation({});
      const returnedDate =
        normalizeDateText(result?.current_date) ||
        normalizeDateText(result?.currentDate) ||
        normalizeDateText(result?.simulation_date) ||
        normalizeDateText(result?.simulationDate);
      setSimulatedCurrentDate(
        skipRestDatesFrom(returnedDate || isoTodayLocal(), {
          skipHolidays: skipStatutoryHolidays,
          weekendMode: weekendRestMode,
          dateModeByDate: dateShiftModeByDate
        })
      );
      if (selectedVersionNo) {
        await refreshTasks(selectedVersionNo);
      }
      setMessage(result?.message || "模拟已重置。");
    } catch (e) {
      setError(e.message || "重置模拟失败");
    } finally {
      setResettingSimulation(false);
    }
  }, [dateShiftModeByDate, refreshTasks, selectedVersionNo, skipStatutoryHolidays, weekendRestMode]);

  const selectedDateMode = useMemo(
    () =>
      resolveDateShiftMode(
        selectedDate,
        skipStatutoryHolidays === true,
        weekendRestMode,
        dateShiftModeByDate
      ),
    [dateShiftModeByDate, selectedDate, skipStatutoryHolidays, weekendRestMode]
  );

  return {
    versions,
    selectedVersionNo,
    setSelectedVersionNo,
    tasks,
    lineTopologyRows,
    skipStatutoryHolidays,
    setSkipStatutoryHolidays,
    weekendRestMode,
    setWeekendRestMode,
    dateShiftModeByDate,
    calendarMonth,
    setCalendarMonth,
    simulatedCurrentDate,
    selectedDate,
    setSelectedDate,
    loadingInit,
    loadingTasks,
    savingRules,
    replanning,
    generatingDraft,
    publishing,
    advancingSimulationDay,
    resettingSimulation,
    activeWorkshopCode,
    setActiveWorkshopCode,
    strategyCode,
    setStrategyCode,
    message,
    error,
    loadingMaterialEstimate,
    materialEstimateError,

    topology,
    dayScheduleByDate,
    calendarWeeks,
    selectedDaySchedule,
    workshopTabs,
    activeWorkshop,
    versionOptions,
    selectedVersionRow,
    canPublishSelected,
    selectedDateMode,
    selectedDateMaterialEstimateRows,
    strategyOptions: STRATEGY_OPTIONS,

    refreshVersionsAndConfig,
    refreshTasks,
    moveCalendarMonth,
    selectCalendarMonth,
    restReasonForDate,
    setDateMode,
    saveRules,
    saveAndReplan,
    generateDraftVersion,
    publishSelectedDraft,
    advanceSimulationOneDay,
    resetManualSimulation
  };
}
