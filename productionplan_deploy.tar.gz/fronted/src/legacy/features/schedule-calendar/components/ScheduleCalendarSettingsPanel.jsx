import { WEEKEND_REST_MODE_OPTIONS } from "../../schedule/calendarModeUtils";

export function ScheduleCalendarSettingsPanel({
  loadingInit,
  selectedVersionNo,
  versionOptions,
  onChangeVersion,
  onRefreshVersionsAndConfig,
  strategyCode,
  strategyOptions,
  onChangeStrategy,
  onGenerateDraftVersion,
  onPublishSelectedDraft,
  skipStatutoryHolidays,
  onToggleSkipStatutoryHolidays,
  weekendRestMode,
  onChangeWeekendRestMode,
  message,
  error,
  topology,
  savingRules,
  replanning,
  generatingDraft,
  publishing,
  advancingSimulationDay,
  resettingSimulation,
  canPublishSelected,
  onSave,
  onAdvanceSimulationOneDay,
  onResetManualSimulation
}) {
  return (
    <div className="panel schedule-calendar-settings">
      <div className="schedule-calendar-settings-head">
        <h3>设置</h3>
        <button
          data-testid="schedule-calendar-save-rules-btn"
          type="button"
          className="btn-success-text"
          disabled={savingRules || replanning || generatingDraft || publishing || !selectedVersionNo}
          onClick={onSave}
        >
          {savingRules ? "保存中..." : replanning ? "重排中..." : "保存并重排"}
        </button>
      </div>

      <div className="toolbar schedule-calendar-controls schedule-calendar-controls-main">
        <label>
          排产版本
          <select
            data-testid="schedule-calendar-version-select"
            value={selectedVersionNo}
            onChange={(e) => onChangeVersion(e.target.value)}
            disabled={loadingInit}
          >
            <option value="">请选择版本</option>
            {versionOptions.map((item) => (
              <option key={item.versionNo} value={item.versionNo}>
                {item.versionNo} / {item.statusName}
              </option>
            ))}
          </select>
        </label>
        <button type="button" onClick={onRefreshVersionsAndConfig}>
          刷新配置
        </button>
      </div>

      <div className="toolbar schedule-calendar-controls schedule-calendar-controls-actions">
        <label>
          排产策略
          <select
            data-testid="schedule-calendar-strategy-select"
            value={strategyCode}
            onChange={(e) => onChangeStrategy(e.target.value)}
            disabled={loadingInit || generatingDraft || publishing}
          >
            {strategyOptions.map((item) => (
              <option key={item.code} value={item.code}>
                {item.label}
              </option>
            ))}
          </select>
        </label>
        <button
          data-testid="schedule-calendar-generate-draft-btn"
          type="button"
          disabled={loadingInit || savingRules || replanning || generatingDraft || publishing}
          onClick={onGenerateDraftVersion}
        >
          {generatingDraft ? "生成中..." : "生成草稿版本"}
        </button>
        <button
          data-testid="schedule-calendar-publish-draft-btn"
          type="button"
          className="btn-primary"
          disabled={
            loadingInit ||
            savingRules ||
            replanning ||
            generatingDraft ||
            publishing ||
            !canPublishSelected
          }
          onClick={onPublishSelectedDraft}
        >
          {publishing ? "发布中..." : "发布草稿"}
        </button>
      </div>

      <div className="toolbar schedule-calendar-controls schedule-calendar-controls-simulation">
        <button
          data-testid="schedule-calendar-sim-advance-day-btn"
          type="button"
          disabled={
            loadingInit ||
            savingRules ||
            replanning ||
            generatingDraft ||
            publishing ||
            advancingSimulationDay ||
            resettingSimulation
          }
          onClick={onAdvanceSimulationOneDay}
        >
          {advancingSimulationDay ? "推进中..." : "推进一天"}
        </button>
        <button
          data-testid="schedule-calendar-sim-reset-btn"
          type="button"
          disabled={
            loadingInit ||
            savingRules ||
            replanning ||
            generatingDraft ||
            publishing ||
            advancingSimulationDay ||
            resettingSimulation
          }
          onClick={onResetManualSimulation}
        >
          {resettingSimulation ? "重置中..." : "重置模拟"}
        </button>
      </div>

      <div className="toolbar schedule-calendar-controls schedule-calendar-controls-rules">
        <label className="schedule-calendar-inline-check">
          <input
            data-testid="schedule-calendar-skip-holidays-toggle"
            type="checkbox"
            checked={skipStatutoryHolidays}
            onChange={(e) => onToggleSkipStatutoryHolidays(e.target.checked)}
          />
          智能跳过法定节假日
        </label>

        <div className="toolbar-choice-group schedule-calendar-weekend-group">
          {WEEKEND_REST_MODE_OPTIONS.map((option) => (
            <label className="lite-mode-option" key={option.value}>
              <input
                type="radio"
                name="calendar-weekend-mode"
                checked={weekendRestMode === option.value}
                onChange={() => onChangeWeekendRestMode(option.value)}
                data-testid={`schedule-calendar-weekend-${option.value.toLowerCase()}`}
              />
              {option.label}
            </label>
          ))}
        </div>
      </div>

      {message ? <p className="notice">{message}</p> : null}
      {error ? <p className="error">{error}</p> : null}

      {topology?.isFallback ? (
        <p className="hint">
          当前未配置车间/产线拓扑，页面会用临时结构辅助预览，但不会把这部分内容写回配置。
        </p>
      ) : null}
    </div>
  );
}
