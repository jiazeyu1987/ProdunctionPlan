"use client";

import { useState } from "react";

type MasterdataTab = "route" | "topology";

const routeRows = [
  { code: "GX-001", product: "造影导管组件 5F" },
  { code: "GX-002", product: "亲水涂层导管套件" },
  { code: "GX-003", product: "导丝保护组件" },
];

const topologyRows = [
  { workshop: "一车间", line: "挤出线 01", process: "挤出" },
  { workshop: "二车间", line: "编织线 03", process: "编织" },
  { workshop: "四车间", line: "包装线 02", process: "包装" },
];

export function MasterdataPage() {
  const [activeTab, setActiveTab] = useState<MasterdataTab>("route");

  return (
    <section className="workspace-page">
      <div className="workspace-page-header">
        <div className="segment-control">
          <button
            type="button"
            className={`segment-item${activeTab === "route" ? " active" : ""}`}
            onClick={() => setActiveTab("route")}
          >
            工艺路线
          </button>
          <button
            type="button"
            className={`segment-item${activeTab === "topology" ? " active" : ""}`}
            onClick={() => setActiveTab("topology")}
          >
            设备拓扑
          </button>
        </div>
      </div>

      <div className="workspace-card">
        {activeTab === "route" ? (
          <>
            <div className="workspace-card-header">
              <div>
                <h1 className="workspace-card-title">工艺路线</h1>
              </div>
            </div>
            <div className="data-table">
              <div className="data-table-header two-cols">
                <span>编号</span>
                <span>产品</span>
              </div>
              <div className="data-table-body">
                {routeRows.map((row) => (
                  <div key={row.code} className="data-table-row two-cols">
                    <span>{row.code}</span>
                    <span>{row.product}</span>
                  </div>
                ))}
              </div>
            </div>
          </>
        ) : (
          <>
            <div className="workspace-card-header">
              <div>
                <h1 className="workspace-card-title">设备拓扑</h1>
              </div>
            </div>
            <div className="topology-grid">
              {topologyRows.map((row) => (
                <article
                  key={`${row.workshop}-${row.line}`}
                  className="topology-card"
                >
                  <div className="topology-workshop">{row.workshop}</div>
                  <div className="topology-line">{row.line}</div>
                  <div className="topology-process">{row.process}</div>
                </article>
              ))}
            </div>
          </>
        )}
      </div>
    </section>
  );
}
