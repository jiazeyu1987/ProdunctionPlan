import { forwardToBackend } from "@/app/api/_shared/backend-proxy";

export async function GET(request: Request) {
  return forwardToBackend(request, "/api/orders");
}
