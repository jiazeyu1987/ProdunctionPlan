﻿import { useState } from "react";
import { postContractAndTrackJob } from "../services/api";

const TAB_ITEMS = [
  { id: "erp-integration", label: "ERP对接验证" },
  { id: "orders-pool", label: "生产订单增强验证" },
  { id: "material-supply", label: "物料自制验证" },
  { id: "material-inventory", label: "物料库存验证" },
];

function newRequestId() {
  return "req-" + Math.random().toString(16).slice(2) + "-" + Date.now().toString(16);
}

function normalizeSpecModel(value) {
  const text = String(value || "").trim();
  if (!text) {
    return "-";
  }

  const bracketMatch = text.match(/Value=([^\]}]+)(?=[\]}]|$)/);
  if (bracketMatch?.[1]) {
    return bracketMatch[1].trim();
  }

  const jsonLikeMatch = text.match(/"Value"\s*:\s*"([^"]+)"/);
  if (jsonLikeMatch?.[1]) {
    return jsonLikeMatch[1].trim();
  }

  return text;
}

async function withTimeout(promise, ms = 60000) {
  let timerId;
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => {
        timerId = window.setTimeout(() => {
          reject(new Error("查询超时，请确认后端 5931 已启动后重试。"));
        }, ms);
      }),
    ]);
  } finally {
    window.clearTimeout(timerId);
  }
}

function ErpIntegrationTab({
  materialCode,
  setMaterialCode,
  count,
  setCount,
  completed,
  setCompleted,
  loading,
  onRunImport,
  error,
  result,
}) {
  return (
    <div className="panel">
      <h3>ERP 订单导入联调</h3>
      <div className="panel-row">
        <div className="panel-item">
          <div className="muted">物料编码</div>
          <input
            value={materialCode}
            onChange={(e) => setMaterialCode(e.target.value)}
            readOnly
            placeholder="例如：YXN.044.02.1020"
            aria-label="物料编码导入"
          />
        </div>
        <div className="panel-item">
          <div className="muted">导入数量 N</div>
          <input
            type="number"
            min={1}
            max={200}
            value={count}
            onChange={(e) => setCount(e.target.value)}
            readOnly
          />
        </div>
        <div className="panel-item">
          <div className="muted">导入状态</div>
          <select
            value={completed ? "DONE" : "OPEN"}
            onChange={(e) => setCompleted(e.target.value === "DONE")}
          >
            <option value="OPEN">未完成（OPEN）</option>
            <option value="DONE">已完成（DONE）</option>
          </select>
        </div>
        <div className="panel-item">
          <div className="muted">操作</div>
          <button className="primary" onClick={onRunImport} disabled={loading || !materialCode.trim()}>
            {loading ? "导入中..." : "从 ERP 导入"}
          </button>
        </div>
      </div>

      {error ? <pre>{error}</pre> : null}
      {result ? <pre>{JSON.stringify(result, null, 2)}</pre> : null}
    </div>
  );
}

function OrdersPoolEnhancementTab() {
  const [orderNo, setOrderNo] = useState("881MO091048");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [rows, setRows] = useState([]);
  const [queryMode, setQueryMode] = useState("fast");

  async function runQuery(mode, targetOrderNo = orderNo) {
    const normalizedOrderNo = String(targetOrderNo || "").trim();
    if (!normalizedOrderNo) {
      setError("请输入生产订单号。");
      setRows([]);
      return;
    }

    setLoading(true);
    setQueryMode(mode);
    setError("");
    try {
      const response = await postContractAndTrackJob("/api/test/erp/material-issues/query", {
        request_id: newRequestId(),
        order_no: normalizedOrderNo,
        mode,
      });
      setRows(Array.isArray(response?.items) ? response.items : []);
    } catch (err) {
      setRows([]);
      setError(err?.message || "查询失败。");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="panel">
      <div className="toolbar">
        <input
          type="search"
          value={orderNo}
          onChange={(e) => setOrderNo(e.target.value)}
          placeholder="请输入生产订单号，例如 881MO091048"
          aria-label="生产订单号查询"
        />
        <button className="primary" onClick={() => runQuery("fast")} disabled={loading}>
          {loading && queryMode === "fast" ? "快速查询中..." : "快速查询"}
        </button>
        <button className="primary" onClick={() => runQuery("real")} disabled={loading}>
          {loading && queryMode === "real" ? "真实查询中..." : "真实查询"}
        </button>
      </div>

      {error ? <p className="error">{error}</p> : null}

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>生产订单号</th>
              <th>子项物料编码</th>
              <th>子项物料名称</th>
              <th>规格型号</th>
            </tr>
          </thead>
          <tbody>
            {rows.length > 0 ? (
              rows.map((row, index) => (
                <tr key={`${row.child_material_code || "row"}-${index}`}>
                  <td>{row.order_no || "-"}</td>
                  <td>{row.child_material_code || "-"}</td>
                  <td>{row.child_material_name_cn || "-"}</td>
                  <td>{normalizeSpecModel(row.spec_model)}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={4}>{loading ? "查询中..." : "暂无数据"}</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function MaterialSupplyTab() {
  const [materialCode, setMaterialCode] = useState("A003.017.01.004");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState(null);

  async function runQuery(targetCode = materialCode) {
    const normalizedMaterialCode = String(targetCode || "").trim();
    if (!normalizedMaterialCode) {
      setError("请输入物料编码。");
      setResult(null);
      return;
    }

    setLoading(true);
    setError("");
    try {
      const response = await postContractAndTrackJob("/api/test/erp/material-supply/query", {
        request_id: newRequestId(),
        material_code: normalizedMaterialCode,
      });
      setResult(response || null);
    } catch (err) {
      setResult(null);
      setError(err?.message || "查询失败。");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="panel">
      <div className="toolbar">
        <input
          type="search"
          value={materialCode}
          onChange={(e) => setMaterialCode(e.target.value)}
          placeholder="请输入物料编码，例如 A003.017.01.004"
          aria-label="物料编码查询"
        />
        <button className="primary" onClick={() => runQuery()} disabled={loading}>
          {loading ? "查询中..." : "查询"}
        </button>
      </div>

      {error ? <p className="error">{error}</p> : null}

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>物料编码</th>
              <th>供应类型</th>
              <th>类型名称</th>
              <th>是否自制</th>
            </tr>
          </thead>
          <tbody>
            {result ? (
              <tr>
                <td>{result.material_code || "-"}</td>
                <td>{result.supply_type || "-"}</td>
                <td>{result.supply_type_name_cn || "-"}</td>
                <td>{result.is_self_made ? "是" : "否"}</td>
              </tr>
            ) : (
              <tr>
                <td colSpan={4}>{loading ? "查询中..." : "暂无数据"}</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function MaterialInventoryTab() {
  const [materialCode, setMaterialCode] = useState("A003.017.01.004");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState(null);

  async function runQuery(targetCode = materialCode) {
    const normalizedMaterialCode = String(targetCode || "").trim();
    if (!normalizedMaterialCode) {
      setError("请输入物料编码。");
      setResult(null);
      return;
    }

    setLoading(true);
    setError("");
    try {
      const response = await postContractAndTrackJob("/api/test/erp/material-inventory/query", {
        request_id: newRequestId(),
        material_code: normalizedMaterialCode,
      });
      setResult(response || null);
    } catch (err) {
      setResult(null);
      setError(err?.message || "查询失败。");
    } finally {
      setLoading(false);
    }
  }

  const rows = Array.isArray(result?.items) ? result.items : [];

  return (
    <div className="panel">
      <div className="toolbar">
        <input
          type="search"
          value={materialCode}
          onChange={(e) => setMaterialCode(e.target.value)}
          placeholder="请输入物料编码，例如 A003.017.01.004"
          aria-label="物料库存查询"
        />
        <button className="primary" onClick={() => runQuery()} disabled={loading}>
          {loading ? "查询中..." : "查询"}
        </button>
      </div>

      {result ? <p className="hint">总库存量：{Number(result.total_stock_qty || 0).toLocaleString("zh-CN")}</p> : null}
      {error ? <p className="error">{error}</p> : null}

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>物料编码</th>
              <th>物料名称</th>
              <th>规格型号</th>
              <th>仓库名称</th>
              <th>批号</th>
              <th>库存主单位</th>
              <th>库存量</th>
              <th>库存组织</th>
            </tr>
          </thead>
          <tbody>
            {rows.length > 0 ? (
              rows.map((row, index) => (
                <tr key={`${row.material_code || "row"}-${row.batch_no || "batch"}-${index}`}>
                  <td>{row.material_code || "-"}</td>
                  <td>{row.material_name_cn || "-"}</td>
                  <td>{normalizeSpecModel(row.spec_model)}</td>
                  <td>{row.warehouse_name || "-"}</td>
                  <td>{row.batch_no || "-"}</td>
                  <td>{row.base_unit_name || "-"}</td>
                  <td>{Number(row.stock_qty || 0).toLocaleString("zh-CN")}</td>
                  <td>{row.stock_org_name || "-"}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={8}>{loading ? "查询中..." : "暂无数据"}</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default function TestToolsPage() {
  const [activeTab, setActiveTab] = useState("erp-integration");
  const [materialCode, setMaterialCode] = useState("YXN.044.02.1020");
  const [count, setCount] = useState(5);
  const [completed, setCompleted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  async function runImport() {
    const normalizedMaterialCode = String(materialCode || "").trim();
    const normalizedCount = Math.max(1, Math.round(Number(count) || 5));
    if (!normalizedMaterialCode) {
      setError("请输入物料编码。");
      setResult(null);
      return;
    }
    setLoading(true);
    setError("");
    setResult(null);
    try {
      const response = await postContractAndTrackJob("/api/test/import-production-orders", {
        request_id: newRequestId(),
        material_code: normalizedMaterialCode,
        n: normalizedCount,
        completed,
      });
      setResult(response);
    } catch (err) {
      setError(err?.message || String(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <section>
      <h2>测试工具</h2>
      <div className="report-tabs" role="tablist" aria-label="测试工具页签">
        {TAB_ITEMS.map((tab) => (
          <button
            key={tab.id}
            type="button"
            role="tab"
            aria-selected={activeTab === tab.id}
            className={activeTab === tab.id ? "active" : ""}
            data-testid={`test-tools-tab-${tab.id}`}
            onClick={() => setActiveTab(tab.id)}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === "erp-integration" ? (
        <ErpIntegrationTab
          materialCode={materialCode}
          setMaterialCode={setMaterialCode}
          count={count}
          setCount={setCount}
          completed={completed}
          setCompleted={setCompleted}
          loading={loading}
          onRunImport={() => runImport()}
          error={error}
          result={result}
        />
      ) : null}

      {activeTab === "orders-pool" ? <OrdersPoolEnhancementTab /> : null}
      {activeTab === "material-supply" ? <MaterialSupplyTab /> : null}
      {activeTab === "material-inventory" ? <MaterialInventoryTab /> : null}
    </section>
  );
}
