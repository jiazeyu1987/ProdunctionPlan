export function PlaceholderPage({
  title,
  description,
}: {
  title: string;
  description: string;
}) {
  return (
    <section className="workspace-page">
      <div className="workspace-card">
        <div className="workspace-card-header">
          <div>
            <h1 className="workspace-card-title">{title}</h1>
            <p className="workspace-card-subtitle">{description}</p>
          </div>
        </div>
        <div className="placeholder-panel">
          <div className="placeholder-mark">{title}</div>
          <p className="placeholder-text">{description}</p>
        </div>
      </div>
    </section>
  );
}
