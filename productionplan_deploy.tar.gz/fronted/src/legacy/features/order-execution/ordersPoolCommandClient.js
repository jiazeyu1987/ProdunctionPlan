import { postContractAndTrackJob } from "../../services/api";

export function createDispatchCommand(payload) {
  return postContractAndTrackJob("/api/dispatch-commands", payload);
}

export function approveDispatchCommand(commandId, payload) {
  return postContractAndTrackJob(
    `/api/dispatch-commands/${commandId}/approvals`,
    payload,
  );
}

export function patchOrderPoolOrder(orderNo, payload) {
  return postContractAndTrackJob(
    `/api/order-pool/${encodeURIComponent(orderNo)}/patch`,
    payload,
  );
}

export function deleteOrderPoolOrder(orderNo, payload = {}) {
  return postContractAndTrackJob(
    `/api/order-pool/${encodeURIComponent(orderNo)}/delete`,
    payload,
  );
}
