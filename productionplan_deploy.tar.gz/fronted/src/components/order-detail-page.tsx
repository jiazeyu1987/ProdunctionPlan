"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import {
  fetchCapacity,
  fetchMaterialChildren,
  fetchOrder,
  fetchOrderMaterials,
  fetchReports,
  refreshInventory,
  refreshOrderMaterials,
  refreshSelfMadeMaterials,
} from "@/lib/api";
import { formatDateTime, formatNumber } from "@/lib/format";
import type {
  CapacityBinding,
  MaterialRow,
  OrderSummary,
  WorkReport,
} from "@/lib/types";

type DetailTab = "detail" | "materials" | "reports" | "capacity";
type MaterialTreeNode = MaterialRow & { level: number };

const detailTabs: Array<{ id: DetailTab; label: string }> = [
  { id: "detail", label: "详情" },
  { id: "materials", label: "清单" },
  { id: "reports", label: "报工" },
  { id: "capacity", label: "产能" },
];

function buildVisibleRows(
  roots: MaterialRow[],
  childrenByParent: Record<string, MaterialRow[]>,
  expandedCodes: Set<string>,
  level = 0,
): MaterialTreeNode[] {
  const rows: MaterialTreeNode[] = [];
  for (const row of roots) {
    rows.push({ ...row, level });
    if (row.expandable && expandedCodes.has(row.child_material_code)) {
      rows.push(
        ...buildVisibleRows(
          childrenByParent[row.child_material_code] ?? [],
          childrenByParent,
          expandedCodes,
          level + 1,
        ),
      );
    }
  }
  return rows;
}

function collectSelfMadeCodes(
  roots: MaterialRow[],
  childrenByParent: Record<string, MaterialRow[]>,
) {
  const codes = new Set<string>();
  [...roots, ...Object.values(childrenByParent).flat()].forEach((row) => {
    if (row.supply_type_code === "SELF_MADE") codes.add(row.child_material_code);
  });
  return Array.from(codes);
}

function collectVisibleCodes(
  roots: MaterialRow[],
  childrenByParent: Record<string, MaterialRow[]>,
) {
  return Array.from(
    new Set([
      ...roots.map((item) => item.child_material_code),
      ...Object.values(childrenByParent)
        .flat()
        .map((item) => item.child_material_code),
    ]),
  );
}

function MaterialRowCard({
  row,
  isOpen,
  isLoading,
  error,
  onToggle,
}: {
  row: MaterialTreeNode;
  isOpen: boolean;
  isLoading: boolean;
  error?: string;
  onToggle: (row: MaterialTreeNode) => void;
}) {
  const inventoryText =
    row.inventory_status === "KNOWN" ? formatNumber(row.inventory_qty) : "未知";

  return (
    <article className={`material-card level-${Math.min(row.level, 2)}`}>
      <div className="row-topline">
        <div className="tree-heading">
          {row.expandable ? (
            <button
              className={`tree-toggle${isOpen ? " is-open" : ""}`}
              type="button"
              onClick={() => onToggle(row)}
              disabled={isLoading}
              aria-label={isOpen ? "折叠子项" : "展开子项"}
            >
              {isOpen ? "−" : "+"}
            </button>
          ) : (
            <span className="tree-spacer" />
          )}
          <div>
            <div className="material-code">{row.child_material_code}</div>
            <div className="material-name">{row.child_material_name}</div>
          </div>
        </div>
        <span
          className={`meta-pill${row.supply_type_code === "SELF_MADE" ? " self-made" : ""}${
            row.inventory_status === "UNKNOWN" ? " unknown" : ""
          }`}
        >
          {row.supply_type_name}
        </span>
      </div>

      <p className="material-spec">{row.spec_model || "未提供规格型号"}</p>

      <div className="row-metrics">
        <div className="metric-chip">
          <div className="metric-chip-label">应发数量</div>
          <div className="metric-chip-value">
            {row.issue_qty == null ? "—" : formatNumber(row.issue_qty)}
          </div>
        </div>
        <div className="metric-chip">
          <div className="metric-chip-label">用量分子 / 分母</div>
          <div className="metric-chip-value">
            {row.usage_numerator == null || row.usage_denominator == null
              ? "—"
              : `${formatNumber(row.usage_numerator)} / ${formatNumber(row.usage_denominator)}`}
          </div>
        </div>
        <div className="metric-chip">
          <div className="metric-chip-label">子项单位</div>
          <div className="metric-chip-value">{row.child_unit || "—"}</div>
        </div>
        <div className="metric-chip">
          <div className="metric-chip-label">即时库存</div>
          <div className="metric-chip-value">{inventoryText}</div>
        </div>
      </div>

      {row.expandable && isLoading ? <p className="notice">子项加载中…</p> : null}
      {row.expandable && error ? <p className="error">{error}</p> : null}
    </article>
  );
}

function ReportsTab({ reports }: { reports: WorkReport[] }) {
  if (reports.length === 0) return <p className="notice">当前订单暂无报工数据。</p>;

  return (
    <div className="table-stack">
      {reports.map((report) => (
        <article className="table-card" key={report.report_id}>
          <h3 className="table-card-title">{report.process_name}</h3>
          <div className="table-card-grid">
            <div className="table-card-item">
              <div className="table-card-item-label">车间</div>
              <div className="table-card-item-value">{report.workshop_name}</div>
            </div>
            <div className="table-card-item">
              <div className="table-card-item-label">产线</div>
              <div className="table-card-item-value">{report.line_name}</div>
            </div>
            <div className="table-card-item">
              <div className="table-card-item-label">报工数量</div>
              <div className="table-card-item-value">{formatNumber(report.report_qty)}</div>
            </div>
            <div className="table-card-item">
              <div className="table-card-item-label">操作人</div>
              <div className="table-card-item-value">{report.operator_name}</div>
            </div>
            <div className="table-card-item">
              <div className="table-card-item-label">报工时间</div>
              <div className="table-card-item-value">{formatDateTime(report.report_time)}</div>
            </div>
          </div>
        </article>
      ))}
    </div>
  );
}

function CapacityTab({ items }: { items: CapacityBinding[] }) {
  if (items.length === 0) return <p className="notice">当前订单暂无产能绑定数据。</p>;

  return (
    <div className="table-stack">
      {items.map((item) => (
        <article
          className="table-card"
          key={`${item.process_code}-${item.workshop_code}-${item.line_code}`}
        >
          <h3 className="table-card-title">{item.process_name}</h3>
          <div className="table-card-grid">
            <div className="table-card-item">
              <div className="table-card-item-label">车间</div>
              <div className="table-card-item-value">{item.workshop_name}</div>
            </div>
            <div className="table-card-item">
              <div className="table-card-item-label">产线</div>
              <div className="table-card-item-value">{item.line_name}</div>
            </div>
            <div className="table-card-item">
              <div className="table-card-item-label">产能</div>
              <div className="table-card-item-value">{formatNumber(item.capacity_qty)}</div>
            </div>
          </div>
        </article>
      ))}
    </div>
  );
}

export function OrderDetailPage({ orderNo }: { orderNo: string }) {
  const [activeTab, setActiveTab] = useState<DetailTab>("detail");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [order, setOrder] = useState<OrderSummary | null>(null);
  const [materials, setMaterials] = useState<MaterialRow[]>([]);
  const [reports, setReports] = useState<WorkReport[]>([]);
  const [capacity, setCapacity] = useState<CapacityBinding[]>([]);
  const [materialsBusy, setMaterialsBusy] = useState(false);
  const [selfMadeBusy, setSelfMadeBusy] = useState(false);
  const [inventoryBusy, setInventoryBusy] = useState(false);
  const [childrenByParent, setChildrenByParent] = useState<Record<string, MaterialRow[]>>({});
  const [nodeLoading, setNodeLoading] = useState<Record<string, boolean>>({});
  const [nodeErrors, setNodeErrors] = useState<Record<string, string>>({});
  const [expandedCodes, setExpandedCodes] = useState<Set<string>>(new Set());

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setLoading(true);
      setError("");
      try {
        const [orderResult, materialsResult, reportsResult, capacityResult] =
          await Promise.all([
            fetchOrder(orderNo),
            fetchOrderMaterials(orderNo),
            fetchReports(orderNo),
            fetchCapacity(orderNo),
          ]);
        if (cancelled) {
          return;
        }
        setOrder(orderResult.item);
        setMaterials(materialsResult.items);
        setReports(reportsResult.items);
        setCapacity(capacityResult.items);
      } catch (loadError) {
        if (!cancelled) {
          setError(
            loadError instanceof Error ? loadError.message : "订单详情加载失败。",
          );
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    load().catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [orderNo]);

  const visibleRows = useMemo(
    () => buildVisibleRows(materials, childrenByParent, expandedCodes),
    [materials, childrenByParent, expandedCodes],
  );

  async function loadChildren(parentMaterialCode: string) {
    setNodeLoading((prev) => ({ ...prev, [parentMaterialCode]: true }));
    setNodeErrors((prev) => ({ ...prev, [parentMaterialCode]: "" }));
    try {
      const response = await fetchMaterialChildren(parentMaterialCode);
      setChildrenByParent((prev) => ({
        ...prev,
        [parentMaterialCode]: response.items,
      }));
    } catch (loadError) {
      setNodeErrors((prev) => ({
        ...prev,
        [parentMaterialCode]:
          loadError instanceof Error ? loadError.message : "子项加载失败。",
      }));
      throw loadError;
    } finally {
      setNodeLoading((prev) => ({ ...prev, [parentMaterialCode]: false }));
    }
  }

  async function handleToggle(row: MaterialTreeNode) {
    if (!row.expandable) return;
    const nextExpanded = new Set(expandedCodes);
    if (nextExpanded.has(row.child_material_code)) {
      nextExpanded.delete(row.child_material_code);
      setExpandedCodes(nextExpanded);
      return;
    }
    nextExpanded.add(row.child_material_code);
    setExpandedCodes(nextExpanded);
    if (!childrenByParent[row.child_material_code]) {
      await loadChildren(row.child_material_code).catch(() => {});
    }
  }

  async function reloadExpandedChildren(parentCodes: string[]) {
    if (parentCodes.length === 0) return;
    const entries = await Promise.all(
      parentCodes.map(async (code) => {
        const response = await fetchMaterialChildren(code);
        return [code, response.items] as const;
      }),
    );
    setChildrenByParent((prev) => {
      const next = { ...prev };
      entries.forEach(([code, items]) => {
        next[code] = items;
      });
      return next;
    });
  }

  async function handleRefreshMaterials() {
    setMaterialsBusy(true);
    setNotice("");
    setError("");
    try {
      const response = await refreshOrderMaterials(orderNo);
      const refreshed = await fetchOrderMaterials(orderNo);
      setMaterials(refreshed.items);
      setChildrenByParent({});
      setExpandedCodes(new Set());
      setNodeErrors({});
      setNotice(response.message);
    } catch (refreshError) {
      setError(refreshError instanceof Error ? refreshError.message : "刷新子物料失败。");
    } finally {
      setMaterialsBusy(false);
    }
  }

  async function handleRefreshSelfMade() {
    const parentCodes = collectSelfMadeCodes(materials, childrenByParent);
    setSelfMadeBusy(true);
    setNotice("");
    setError("");
    try {
      const response = await refreshSelfMadeMaterials(orderNo, parentCodes);
      await reloadExpandedChildren(Array.from(expandedCodes));
      setNotice(response.message);
    } catch (refreshError) {
      setError(refreshError instanceof Error ? refreshError.message : "刷新自制失败。");
    } finally {
      setSelfMadeBusy(false);
    }
  }

  async function handleRefreshInventory() {
    const materialCodes = collectVisibleCodes(materials, childrenByParent);
    setInventoryBusy(true);
    setNotice("");
    setError("");
    try {
      const response = await refreshInventory(materialCodes);
      const refreshed = await fetchOrderMaterials(orderNo);
      setMaterials(refreshed.items);
      await reloadExpandedChildren(Array.from(expandedCodes));
      setNotice(response.message);
    } catch (refreshError) {
      setError(refreshError instanceof Error ? refreshError.message : "刷新库存失败。");
    } finally {
      setInventoryBusy(false);
    }
  }

  return (
    <main className="mobile-shell">
      <header className="mini-app-header">
        <div className="mini-app-brand">
          <div className="mini-app-badge">单</div>
          <div>
            <h1 className="mini-app-title">生产订单详情</h1>
            <p className="mini-app-subtitle">Mock API / 小程序风格详情页</p>
          </div>
        </div>
      </header>

      <Link className="btn-ghost" href="/orders">
        ← 返回订单池
      </Link>

      {loading ? <p className="notice">订单详情加载中…</p> : null}
      {error && !order ? <p className="error">{error}</p> : null}

      {order ? (
        <>
          <section className="hero-card" style={{ marginTop: 14 }}>
            <div className="detail-topline">
              <div>
                <div className="detail-order-no">{order.production_order_no}</div>
                <h2 className="card-title" style={{ marginTop: 10 }}>
                  {order.material_name}
                </h2>
                <p className="card-subtitle">
                  {order.material_code}
                  <br />
                  {order.material_specification}
                </p>
              </div>
              <span className="status-pill is-active">{order.status}</span>
            </div>

            <div className="detail-grid">
              <div className="fact-box">
                <div className="fact-label">生产数量</div>
                <div className="fact-value">{formatNumber(order.production_qty)}</div>
              </div>
              <div className="fact-box">
                <div className="fact-label">BOM 单号</div>
                <div className="fact-value">{order.material_list_no}</div>
              </div>
              <div className="fact-box">
                <div className="fact-label">计划开始</div>
                <div className="fact-value">{order.planned_start_date}</div>
              </div>
              <div className="fact-box">
                <div className="fact-label">计划结束</div>
                <div className="fact-value">{order.planned_end_date}</div>
              </div>
            </div>
          </section>

          <nav className="detail-nav">
            {detailTabs.map((tab) => (
              <button
                key={tab.id}
                className={`tab-chip${activeTab === tab.id ? " active" : ""}`}
                type="button"
                onClick={() => setActiveTab(tab.id)}
              >
                {tab.label}
              </button>
            ))}
          </nav>

          <section className="tab-panel">
            {error && order ? <p className="error">{error}</p> : null}
            {notice ? <p className="notice">{notice}</p> : null}

            {activeTab === "detail" ? (
              <div className="section-stack">
                <div>
                  <h2 className="tab-title">详情</h2>
                  <p className="tab-desc">展示订单基础信息与计划信息。</p>
                </div>
                <div className="table-card-grid">
                  <div className="table-card-item">
                    <div className="table-card-item-label">订单号</div>
                    <div className="table-card-item-value">{order.production_order_no}</div>
                  </div>
                  <div className="table-card-item">
                    <div className="table-card-item-label">产品编码</div>
                    <div className="table-card-item-value">{order.material_code}</div>
                  </div>
                  <div className="table-card-item">
                    <div className="table-card-item-label">产品名称</div>
                    <div className="table-card-item-value">{order.material_name}</div>
                  </div>
                  <div className="table-card-item">
                    <div className="table-card-item-label">来源单据</div>
                    <div className="table-card-item-value">{order.source_bill_no}</div>
                  </div>
                  <div className="table-card-item">
                    <div className="table-card-item-label">规格型号</div>
                    <div className="table-card-item-value">{order.material_specification}</div>
                  </div>
                </div>
              </div>
            ) : null}

            {activeTab === "materials" ? (
              <div className="section-stack">
                <div className="toolbar-row">
                  <div>
                    <h2 className="tab-title">清单</h2>
                    <p className="tab-desc">
                      根层子物料 + 自制子物料展开，接口全部走 mock API。
                    </p>
                  </div>
                  <div className="toolbar-actions">
                    <button
                      className="btn-light"
                      type="button"
                      onClick={() => handleRefreshSelfMade().catch(() => {})}
                      disabled={selfMadeBusy}
                    >
                      {selfMadeBusy ? "刷新中…" : "刷新自制"}
                    </button>
                    <button
                      className="btn-ghost"
                      type="button"
                      onClick={() => handleRefreshInventory().catch(() => {})}
                      disabled={inventoryBusy}
                    >
                      {inventoryBusy ? "刷新中…" : "刷新库存"}
                    </button>
                    <button
                      className="btn"
                      type="button"
                      onClick={() => handleRefreshMaterials().catch(() => {})}
                      disabled={materialsBusy}
                    >
                      {materialsBusy ? "刷新中…" : "刷新子物料"}
                    </button>
                  </div>
                </div>

                {visibleRows.length === 0 ? (
                  <p className="notice">当前订单暂无生产用料清单。</p>
                ) : (
                  visibleRows.map((row) => (
                    <MaterialRowCard
                      key={`${row.parent_material_code ?? row.production_order_no ?? "root"}-${row.child_material_code}`}
                      row={row}
                      isOpen={expandedCodes.has(row.child_material_code)}
                      isLoading={Boolean(nodeLoading[row.child_material_code])}
                      error={nodeErrors[row.child_material_code]}
                      onToggle={(nextRow) => handleToggle(nextRow).catch(() => {})}
                    />
                  ))
                )}
              </div>
            ) : null}

            {activeTab === "reports" ? (
              <div className="section-stack">
                <div>
                  <h2 className="tab-title">报工</h2>
                  <p className="tab-desc">展示当前订单的历史报工数据。</p>
                </div>
                <ReportsTab reports={reports} />
              </div>
            ) : null}

            {activeTab === "capacity" ? (
              <div className="section-stack">
                <div>
                  <h2 className="tab-title">产能</h2>
                  <p className="tab-desc">展示工序、车间、产线对应及基础产能。</p>
                </div>
                <CapacityTab items={capacity} />
              </div>
            ) : null}
          </section>
        </>
      ) : null}
    </main>
  );
}
