import { postContractAndTrackJob } from "../../services/api";

export function createDispatchCommand(payload) {
  return postContractAndTrackJob("/api/dispatch-commands", payload);
}

export function approveDispatchCommand(commandId, payload) {
  return postContractAndTrackJob(`/api/dispatch-commands/${commandId}/approvals`, payload);
}

export function advanceSimulationOneDay(payload) {
  return postContractAndTrackJob("/api/simulation/manual/advance-day", payload);
}

export function resetManualSimulation(payload = {}) {
  return postContractAndTrackJob("/api/simulation/manual/reset", payload);
}
