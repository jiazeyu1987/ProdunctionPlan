﻿"use client";

import { BrowserRouter } from "react-router-dom";
import LegacyApp from "@/legacy/App";

export function LegacyAppPage() {
  return (
    <BrowserRouter>
      <LegacyApp />
    </BrowserRouter>
  );
}
