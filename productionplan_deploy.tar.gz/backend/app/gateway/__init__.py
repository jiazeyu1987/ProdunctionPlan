"""ERP gateway layer."""
