import { NavLink, Navigate, Route, Routes, useLocation } from "react-router-dom";
import ExecutionWipPage from "./pages/ExecutionWipPage";
import LiteSchedulerPage from "./pages/LiteSchedulerPage";
import MasterdataPage from "./pages/MasterdataPage";
import OrdersPoolPage from "./pages/OrdersPoolPage";
import ScheduleCalendarPage from "./pages/ScheduleCalendarPage";
import TestToolsPage from "./pages/TestToolsPage";

const MAIN_LINKS = [
  ["/schedule/calendar", "月历排期"],
  ["/orders/pool", "生产订单"],
  ["/execution/wip", "报工"],
  ["/masterdata", "主数据"],
  ["/test", "测试"],
];

function AppShell() {
  const location = useLocation();
  const isLiteSchedulerPage = location.pathname === "/schedule/lite";
  const links = isLiteSchedulerPage ? [["/schedule/calendar", "返回"]] : MAIN_LINKS;

  return (
    <div className="layout">
      <aside className="sidebar">
        {!isLiteSchedulerPage ? (
          <NavLink className="sidebar-brand" to="/schedule/lite">
            集团排产
          </NavLink>
        ) : null}
        <nav>
          {links.map(([to, label]) => (
            <NavLink key={to} to={to} className={({ isActive }) => (isActive ? "active" : "")}>
              {label}
            </NavLink>
          ))}
        </nav>
      </aside>
      <main className="content">
        <Routes>
          <Route path="/" element={<Navigate to="/schedule/calendar" replace />} />
          <Route path="/dashboard" element={<Navigate to="/schedule/calendar" replace />} />
          <Route path="/workbenches" element={<Navigate to="/schedule/calendar" replace />} />
          <Route path="/tasks" element={<Navigate to="/schedule/calendar" replace />} />
          <Route path="/orders/pool" element={<OrdersPoolPage />} />
          <Route path="/schedule/board" element={<Navigate to="/schedule/calendar" replace />} />
          <Route path="/schedule/lite" element={<LiteSchedulerPage />} />
          <Route path="/schedule/calendar" element={<ScheduleCalendarPage />} />
          <Route path="/reports/plans" element={<Navigate to="/schedule/calendar" replace />} />
          <Route path="/schedule/versions" element={<Navigate to="/schedule/calendar" replace />} />
          <Route path="/dispatch/commands" element={<Navigate to="/schedule/calendar" replace />} />
          <Route path="/execution/wip" element={<ExecutionWipPage />} />
          <Route path="/alerts" element={<Navigate to="/schedule/calendar" replace />} />
          <Route path="/audit/logs" element={<Navigate to="/schedule/calendar" replace />} />
          <Route path="/masterdata" element={<MasterdataPage />} />
          <Route path="/ops/integration" element={<Navigate to="/schedule/calendar" replace />} />
          <Route path="/guide" element={<Navigate to="/schedule/calendar" replace />} />
          <Route path="/test" element={<TestToolsPage />} />
        </Routes>
      </main>
    </div>
  );
}

export default function App() {
  return <AppShell />;
}
