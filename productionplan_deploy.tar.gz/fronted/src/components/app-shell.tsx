"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const navItems = [
  { href: "/schedule/calendar", label: "月历排期" },
  { href: "/orders", label: "生产订单" },
  { href: "/reports", label: "报工" },
  { href: "/masterdata", label: "主数据" },
  { href: "/test", label: "测试" },
];

function isActive(pathname: string, href: string) {
  if (href === "/masterdata") {
    return pathname === "/masterdata" || pathname === "/";
  }

  return pathname === href || pathname.startsWith(`${href}/`);
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  return (
    <div className="workspace-shell">
      <aside className="workspace-sidebar">
        <div className="workspace-brand">集团排产</div>
        <nav className="workspace-nav">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`workspace-nav-item${isActive(pathname, item.href) ? " active" : ""}`}
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </aside>
      <div className="workspace-main">{children}</div>
    </div>
  );
}
