﻿# masterdata feature

Owns masterdata read/write clients, orchestration helpers, and editor utilities.

1. `queryClient.js`: masterdata and calendar-rule reads.
2. `commandClient.js`: masterdata write operations.
3. `service.js`: bootstrap and route-save orchestration.
4. `index.js`: feature root export for pages, services, and shared utilities.

Recommended imports:

1. Prefer importing from `../masterdata`.
2. Use `queryClient.js` and `commandClient.js` directly in focused tests.
