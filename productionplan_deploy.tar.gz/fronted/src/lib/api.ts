import type {
  CapacityBinding,
  CommandResponse,
  ItemResponse,
  ListResponse,
  MaterialRow,
  OrderSummary,
  WorkReport,
} from "@/lib/types";
import { submitCommandAndTrackJob } from "@/lib/jobs";

type OrdersQuery = {
  keyword?: string;
  status?: string;
};

async function parseResponse<T>(response: Response): Promise<T> {
  const payload = await response.json().catch(() => null);
  if (!response.ok) {
    const message =
      payload && typeof payload.message === "string"
        ? payload.message
        : "请求失败。";
    throw new Error(message);
  }
  return payload as T;
}

export async function fetchOrders(query: OrdersQuery) {
  const params = new URLSearchParams();
  if (query.keyword) params.set("keyword", query.keyword);
  if (query.status) params.set("status", query.status);
  const response = await fetch(`/api/orders?${params.toString()}`, {
    cache: "no-store",
  });
  return parseResponse<ListResponse<OrderSummary>>(response);
}

export async function fetchOrder(orderNo: string) {
  return parseResponse<ItemResponse<OrderSummary>>(
    await fetch(`/api/orders/${orderNo}`, { cache: "no-store" }),
  );
}

export async function fetchOrderMaterials(orderNo: string) {
  return parseResponse<ListResponse<MaterialRow>>(
    await fetch(`/api/orders/${orderNo}/materials`, { cache: "no-store" }),
  );
}

export async function refreshOrderMaterials(orderNo: string) {
  const { finalJob } = await submitCommandAndTrackJob({
    path: `/api/orders/${orderNo}/materials/refresh`,
  });
  return {
    success: true,
    message:
      typeof finalJob.result?.message === "string"
        ? finalJob.result.message
        : "Task completed.",
  } satisfies CommandResponse;
}

export async function refreshSelfMadeMaterials(
  orderNo: string,
  parentMaterialCodes: string[],
) {
  const { finalJob } = await submitCommandAndTrackJob({
    path: `/api/orders/${orderNo}/self-made-materials/refresh`,
    body: { parent_material_codes: parentMaterialCodes },
  });
  return {
    success: true,
    message:
      typeof finalJob.result?.message === "string"
        ? finalJob.result.message
        : "Task completed.",
  } satisfies CommandResponse;
}

export async function fetchMaterialChildren(parentMaterialCode: string) {
  return parseResponse<ListResponse<MaterialRow>>(
    await fetch(`/api/materials/${parentMaterialCode}/children`, {
      cache: "no-store",
    }),
  );
}

export async function refreshInventory(materialCodes: string[]) {
  const { finalJob } = await submitCommandAndTrackJob({
    path: `/api/inventory/refresh`,
    body: { material_codes: materialCodes },
  });
  return {
    success: true,
    message:
      typeof finalJob.result?.message === "string"
        ? finalJob.result.message
        : "Task completed.",
  } satisfies CommandResponse;
}

export async function fetchReports(orderNo: string) {
  return parseResponse<ListResponse<WorkReport>>(
    await fetch(`/api/orders/${orderNo}/reports`, { cache: "no-store" }),
  );
}

export async function fetchCapacity(orderNo: string) {
  return parseResponse<ListResponse<CapacityBinding>>(
    await fetch(`/api/orders/${orderNo}/capacity`, { cache: "no-store" }),
  );
}
