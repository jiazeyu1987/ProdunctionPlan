import { useState } from "react";
import SimpleTable from "../../../components/SimpleTable";
import ProductCell from "../ProductCell";
import { orderStatusText, progressText, toIntText } from "..";
import { formatDate } from "../../../utils/datetime";
import OrdersPoolMaterialsPanel from "./OrdersPoolMaterialsPanel";

const TAB_DETAIL = "detail";
const TAB_MATERIALS = "materials";
const TAB_REPORTINGS = "reportings";
const TAB_CAPACITY = "capacity";

export default function OrdersPoolOrderDetailPanel({
  selectedOrder,
  selectedOrderNo,
  selectedOrderIsScheduled,
  selectedOrderInProgress,
  expectedStartDraft,
  onExpectedStartDraftChange,
  submitting,
  onSaveExpectedStartTime,
  finishedSummary,
  materialsLoading,
  materialsRefreshing,
  selfMadeRefreshing,
  inventoryRefreshing,
  materialsError,
  materialsRefreshWarning,
  materialTreeRows,
  onRefreshMaterialsFromErp,
  onRefreshSelfMadeFromErp,
  onRefreshInventoryFromErp,
  onToggleMaterialNode,
  selectedOrderReportings,
  selectedOrderProcessContexts,
}) {
  const [activeTab, setActiveTab] = useState(TAB_DETAIL);

  if (!selectedOrder) {
    return null;
  }

  return (
    <div className="panel">
      <h3>生产订单详情</h3>
      <div className="report-tabs orders-pool-detail-tabs" role="tablist" aria-label="生产订单详情标签页">
        <button type="button" className={activeTab === TAB_DETAIL ? "active" : ""} onClick={() => setActiveTab(TAB_DETAIL)}>
          详情
        </button>
        <button type="button" className={activeTab === TAB_MATERIALS ? "active" : ""} onClick={() => setActiveTab(TAB_MATERIALS)}>
          清单
        </button>
        <button type="button" className={activeTab === TAB_REPORTINGS ? "active" : ""} onClick={() => setActiveTab(TAB_REPORTINGS)}>
          报工
        </button>
        <button type="button" className={activeTab === TAB_CAPACITY ? "active" : ""} onClick={() => setActiveTab(TAB_CAPACITY)}>
          产能
        </button>
      </div>
      {selectedOrderIsScheduled ? <p className="notice">该生产订单已进入排产。</p> : null}

      {activeTab === TAB_DETAIL ? (
        <div className="table-wrap">
          <table>
            <tbody>
              <tr>
                <th>生产订单号</th>
                <td>{selectedOrder.order_no}</td>
                <th>产品</th>
                <td>
                  <ProductCell
                    code={selectedOrder.product_code}
                    name={selectedOrder.product_name_cn || selectedOrder.product_code}
                  />
                </td>
              </tr>
              <tr>
                <th>数量</th>
                <td>{selectedOrder.order_qty ?? "-"}</td>
                <th>承诺交期</th>
                <td>{formatDate(selectedOrder.promised_due_date) ?? "-"}</td>
              </tr>
              <tr>
                <th>预计开始时间</th>
                <td>{formatDate(selectedOrder.expected_start_time) ?? "-"}</td>
                <th>预计完成时间</th>
                <td>{formatDate(selectedOrder.expected_finish_time) ?? "-"}</td>
              </tr>
              <tr>
                <th>调整预计开始</th>
                <td colSpan={3}>
                  <div className="toolbar">
                    <input
                      type="date"
                      value={expectedStartDraft}
                      onChange={(e) => onExpectedStartDraftChange(e.target.value)}
                      disabled={submitting}
                    />
                    <button disabled={submitting || !expectedStartDraft} onClick={onSaveExpectedStartTime}>
                      保存并重算预计完成时间
                    </button>
                  </div>
                </td>
              </tr>
              <tr>
                <th>优先级</th>
                <td>{Number.isFinite(Number(selectedOrder.priority_level)) ? Number(selectedOrder.priority_level) : 5}</td>
                <th>冻结</th>
                <td>{Number(selectedOrder.frozen_flag) === 1 ? "是" : "否"}</td>
              </tr>
              <tr>
                <th>状态</th>
                <td colSpan={3}>{orderStatusText(selectedOrder)}</td>
              </tr>
              <tr>
                <th>进行中进度</th>
                <td colSpan={3}>
                  {selectedOrderInProgress ? progressText(selectedOrder) : "-"}
                </td>
              </tr>
              <tr>
                <th>成品完成数量</th>
                <td>{toIntText(finishedSummary.finishedQty)}</td>
                <th>批次</th>
                <td>{finishedSummary.batchNo}</td>
              </tr>
              <tr>
                <th>成品完成日期</th>
                <td>{formatDate(finishedSummary.finishedDate) ?? "-"}</td>
                <th>总量</th>
                <td>{toIntText(finishedSummary.totalQty)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      ) : null}

      {activeTab === TAB_MATERIALS ? (
        <OrdersPoolMaterialsPanel
          selectedOrderNo={selectedOrderNo}
          materialsLoading={materialsLoading}
          materialsRefreshing={materialsRefreshing}
          selfMadeRefreshing={selfMadeRefreshing}
          inventoryRefreshing={inventoryRefreshing}
          materialsError={materialsError}
          materialsRefreshWarning={materialsRefreshWarning}
          materialTreeRows={materialTreeRows}
          onRefreshMaterialsFromErp={onRefreshMaterialsFromErp}
          onRefreshSelfMadeFromErp={onRefreshSelfMadeFromErp}
          onRefreshInventoryFromErp={onRefreshInventoryFromErp}
          onToggleMaterialNode={onToggleMaterialNode}
        />
      ) : null}

      {activeTab === TAB_REPORTINGS ? (
        <>
          <h3>历史报工数据</h3>
          <SimpleTable
            columns={[
              { key: "report_id", title: "报工ID" },
              {
                key: "process_code",
                title: "工序",
                render: (value, row) => row.process_name_cn || value || "-",
              },
              {
                key: "report_qty",
                title: "报工数量",
                render: (value) => toIntText(value),
              },
              { key: "report_time", title: "报工时间" },
            ]}
            rows={selectedOrderReportings}
          />
        </>
      ) : null}

      {activeTab === TAB_CAPACITY ? (
        <>
          <h3>工序-车间-产线对应</h3>
          <SimpleTable
            columns={[
              { key: "sequence_no", title: "顺序" },
              { key: "process_name_cn", title: "工序" },
              { key: "workshop_code", title: "车间" },
              { key: "line_code", title: "产线" },
            ]}
            rows={selectedOrderProcessContexts}
          />
        </>
      ) : null}
    </div>
  );
}
