export default function OrdersPoolToolbar({
  submitting,
  onRefresh,
  productKeyword,
  onProductKeywordChange,
  orderStatusFilter,
  onOrderStatusFilterChange,
}) {
  return (
    <div className="toolbar">
      <button disabled={submitting} onClick={onRefresh}>
        刷新
      </button>
      <input
        type="search"
        value={productKeyword}
        onChange={(e) => onProductKeywordChange(e.target.value)}
        placeholder="按产品编码 / 名称过滤"
        aria-label="产品关键词过滤"
      />
      <label className="toolbar-select">
        <span>状态筛选</span>
        <select
          value={orderStatusFilter}
          onChange={(e) => onOrderStatusFilterChange(e.target.value)}
          aria-label="订单状态过滤"
        >
          <option value="">全部状态</option>
          <option value="OPEN">待处理（OPEN）</option>
          <option value="IN_PROGRESS">进行中（IN_PROGRESS）</option>
          <option value="DONE">已完成（DONE）</option>
          <option value="DELAY">延期（DELAY）</option>
        </select>
      </label>
    </div>
  );
}
