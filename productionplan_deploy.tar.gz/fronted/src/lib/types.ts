export type InventoryStatus = "KNOWN" | "UNKNOWN";

export type OrderStatus = "计划确认" | "生产中" | "待发料" | "已完工";

export type SupplyTypeCode = "SELF_MADE" | "PURCHASED";

export type SupplyTypeName = "自制" | "外购";

export type OrderSummary = {
  production_order_no: string;
  material_code: string;
  material_name: string;
  material_specification: string;
  production_qty: number;
  status: OrderStatus;
  material_list_no: string;
  planned_start_date: string;
  planned_end_date: string;
  source_bill_no: string;
};

export type MaterialRow = {
  row_type: "ROOT" | "CHILD";
  production_order_no: string | null;
  parent_material_code: string | null;
  child_material_code: string;
  child_material_name: string;
  spec_model: string | null;
  issue_qty: number | null;
  usage_numerator: number | null;
  usage_denominator: number | null;
  child_unit: string | null;
  supply_type_code: SupplyTypeCode;
  supply_type_name: SupplyTypeName;
  inventory_qty: number | null;
  inventory_status: InventoryStatus;
  expandable: boolean;
};

export type WorkReport = {
  report_id: string;
  production_order_no: string;
  process_name: string;
  workshop_name: string;
  line_name: string;
  report_qty: number;
  report_time: string;
  operator_name: string;
};

export type CapacityBinding = {
  process_code: string;
  process_name: string;
  workshop_code: string;
  workshop_name: string;
  line_code: string;
  line_name: string;
  capacity_qty: number;
};

export type ListResponse<T> = {
  items: T[];
  total: number;
};

export type ItemResponse<T> = {
  item: T;
};

export type CommandResponse = {
  success: boolean;
  message: string;
};

export type JobStatus = "PENDING" | "RUNNING" | "SUCCEEDED" | "FAILED";

export type AcceptedCommandResponse = {
  success: boolean;
  job_id: string;
  status_url: string;
  message: string;
};

export type JobRecord = {
  job_id: string;
  job_type: string;
  target_type: string;
  target_key: string;
  request_id: string | null;
  status: JobStatus;
  progress: number;
  payload: Record<string, unknown> | null;
  result: Record<string, unknown> | null;
  error_code: string | null;
  error_message: string | null;
  created_at: string;
  started_at: string | null;
  finished_at: string | null;
};
