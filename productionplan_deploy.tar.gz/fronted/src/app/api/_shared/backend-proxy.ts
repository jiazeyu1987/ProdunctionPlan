import { NextResponse } from "next/server";

function buildBackendUrl(pathname: string, requestUrl: string) {
  const baseUrl = process.env.BACKEND_API_BASE_URL;
  if (!baseUrl) {
    throw new Error("BACKEND_API_BASE_URL is not configured.");
  }

  const incomingUrl = new URL(requestUrl);
  const backendUrl = new URL(pathname, `${baseUrl.replace(/\/$/, "")}/`);
  backendUrl.search = incomingUrl.search;
  return backendUrl;
}

export async function forwardToBackend(request: Request, pathname: string) {
  let backendUrl: URL;
  try {
    backendUrl = buildBackendUrl(pathname, request.url);
  } catch (error) {
    return NextResponse.json(
      {
        code: "BACKEND_PROXY_CONFIG_ERROR",
        message: error instanceof Error ? error.message : "Backend proxy is not configured.",
      },
      { status: 500 },
    );
  }

  const headers = new Headers();
  const contentType = request.headers.get("content-type");
  if (contentType) {
    headers.set("content-type", contentType);
  }
  headers.set("accept", "application/json");

  const body =
    request.method === "GET" || request.method === "HEAD"
      ? undefined
      : await request.text();

  let response: Response;
  try {
    response = await fetch(backendUrl, {
      method: request.method,
      headers,
      body,
      cache: "no-store",
    });
  } catch (error) {
    return NextResponse.json(
      {
        code: "BACKEND_UNREACHABLE",
        message: error instanceof Error ? error.message : "Backend request failed.",
      },
      { status: 502 },
    );
  }

  const text = await response.text();
  return new NextResponse(text, {
    status: response.status,
    headers: {
      "content-type":
        response.headers.get("content-type") ?? "application/json; charset=utf-8",
    },
  });
}
