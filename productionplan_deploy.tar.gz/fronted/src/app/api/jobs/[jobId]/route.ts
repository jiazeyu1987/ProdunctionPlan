import { forwardToBackend } from "@/app/api/_shared/backend-proxy";

export async function GET(
  request: Request,
  context: { params: Promise<{ jobId: string }> },
) {
  const { jobId } = await context.params;
  return forwardToBackend(request, `/api/jobs/${jobId}`);
}
