﻿# Order Execution Feature

This folder contains feature-level API clients and orchestration modules for:

1. `OrdersPoolPage`
2. `ExecutionWipPage`

Current structure:

1. `ordersPoolQueryClient.js` for query/read operations.
2. `ordersPoolCommandClient.js` for command/write operations.
3. `reportingQueryClient.js` for report listing/filter queries.
4. `reportingCommandClient.js` for report submit/delete commands.
5. `ordersPoolService.js` extracts OrdersPoolPage API orchestration.
6. `index.js` re-exports the query/command clients as the feature root.

Recommended imports moving forward:

1. Page/controller code should prefer the feature root export: `../order-execution`.
2. The feature root re-exports query/command clients directly.
