import type {
  AcceptedCommandResponse,
  ItemResponse,
  JobRecord,
  JobStatus,
} from "@/lib/types";

type CommandMethod = "POST" | "PUT" | "PATCH" | "DELETE";

type PollJobOptions = {
  signal?: AbortSignal;
  intervalMs?: number;
  maxAttempts?: number;
  onJobUpdate?: (job: JobRecord) => void;
};

type SubmitCommandOptions<TBody> = PollJobOptions & {
  path: string;
  method?: CommandMethod;
  body?: TBody;
};

type SubmitCommandResult = {
  accepted: AcceptedCommandResponse;
  finalJob: JobRecord;
};

const TERMINAL_JOB_STATUSES: JobStatus[] = ["SUCCEEDED", "FAILED"];

function createRequestId() {
  return `web-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

async function parseResponse<T>(response: Response): Promise<T> {
  const payload = await response.json().catch(() => null);
  if (!response.ok) {
    const message =
      payload && typeof payload.message === "string"
        ? payload.message
        : "Request failed.";
    throw new Error(message);
  }
  return payload as T;
}

function buildCommandPayload(body: unknown) {
  if (body === undefined) {
    return { request_id: createRequestId() };
  }

  if (body === null || Array.isArray(body) || typeof body !== "object") {
    throw new Error(
      "Command payload must be an object so request_id can be attached.",
    );
  }

  const payload = { ...(body as Record<string, unknown>) };
  if (typeof payload.request_id !== "string" || !payload.request_id.trim()) {
    payload.request_id = createRequestId();
  }
  return payload;
}

function sleep(ms: number, signal?: AbortSignal) {
  return new Promise<void>((resolve, reject) => {
    if (signal?.aborted) {
      reject(new Error("The operation was aborted."));
      return;
    }

    const timer = globalThis.setTimeout(() => {
      cleanup();
      resolve();
    }, ms);

    function onAbort() {
      cleanup();
      reject(new Error("The operation was aborted."));
    }

    function cleanup() {
      globalThis.clearTimeout(timer);
      signal?.removeEventListener("abort", onAbort);
    }

    signal?.addEventListener("abort", onAbort, { once: true });
  });
}

export async function fetchJob(jobId: string, signal?: AbortSignal) {
  return parseResponse<ItemResponse<JobRecord>>(
    await fetch(`/api/jobs/${jobId}`, {
      cache: "no-store",
      signal,
    }),
  );
}

export async function pollJobUntilFinished(
  jobId: string,
  options: PollJobOptions = {},
) {
  const { signal, intervalMs = 1500, maxAttempts = 120, onJobUpdate } = options;

  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    const { item } = await fetchJob(jobId, signal);
    onJobUpdate?.(item);

    if (TERMINAL_JOB_STATUSES.includes(item.status)) {
      if (item.status === "FAILED") {
        throw new Error(item.error_message || "Job execution failed.");
      }
      return item;
    }

    if (attempt < maxAttempts) {
      await sleep(intervalMs, signal);
    }
  }

  throw new Error("Job polling timed out before completion.");
}

export async function submitCommandAndTrackJob<TBody = Record<string, unknown>>(
  options: SubmitCommandOptions<TBody>,
): Promise<SubmitCommandResult> {
  const {
    path,
    method = "POST",
    body,
    signal,
    intervalMs,
    maxAttempts,
    onJobUpdate,
  } = options;

  const payload = buildCommandPayload(body);
  const accepted = await parseResponse<AcceptedCommandResponse>(
    await fetch(path, {
      method,
      signal,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    }),
  );

  const finalJob = await pollJobUntilFinished(accepted.job_id, {
    signal,
    intervalMs,
    maxAttempts,
    onJobUpdate,
  });

  return { accepted, finalJob };
}
