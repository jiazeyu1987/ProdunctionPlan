import {
  DATE_SHIFT_MODE,
  DATE_SHIFT_MODE_LABEL,
  dayModeButtonClass,
  nightModeButtonClass,
  resolveDateShiftMode
} from "../../schedule/calendarModeUtils";
import { WEEKDAY_LABELS } from "../scheduleCalendarConstants";

const MAX_VISIBLE_ORDER_COUNT = 2;

export function ScheduleCalendarGrid({
  calendarWeeks,
  dayScheduleByDate,
  currentDate,
  selectedDate,
  skipStatutoryHolidays,
  weekendRestMode,
  dateShiftModeByDate,
  onSelectDate,
  onSetDateMode,
  restReasonForDate
}) {
  const todayText = String(currentDate || "").trim();

  return (
    <div className="lite-calendar-wrap">
      <div className="lite-calendar-head">
        {WEEKDAY_LABELS.map((label) => (
          <div key={label} className="lite-calendar-weekday">
            {label}
          </div>
        ))}
      </div>
      <div className="lite-calendar-grid">
        {calendarWeeks.flatMap((week, weekIdx) =>
          week.map((date, dayIdx) => {
            if (!date) {
              return (
                <article
                  key={`empty-${weekIdx}-${dayIdx}`}
                  className="lite-calendar-cell lite-calendar-cell-empty"
                />
              );
            }

            const daySchedule = dayScheduleByDate[date];
            const effectiveMode = resolveDateShiftMode(
              date,
              skipStatutoryHolidays === true,
              weekendRestMode,
              dateShiftModeByDate
            );
            const isRest = effectiveMode === DATE_SHIFT_MODE.REST;
            const reason = restReasonForDate(date);
            const taskCount = Number(daySchedule?.taskCount || 0);
            const orderCount = Number(daySchedule?.orderCount || 0);
            const orderNos = Array.isArray(daySchedule?.orderNos) ? daySchedule.orderNos : [];
            const visibleOrderNos = orderNos.slice(0, MAX_VISIBLE_ORDER_COUNT);
            const hiddenOrderCount = Math.max(0, orderNos.length - visibleOrderNos.length);
            const shiftLabel = DATE_SHIFT_MODE_LABEL[effectiveMode] || DATE_SHIFT_MODE_LABEL.DAY;

            return (
              <article
                key={`${weekIdx}-${date}`}
                data-testid={`schedule-calendar-day-${date}`}
                className={[
                  "lite-calendar-cell",
                  isRest ? "lite-calendar-cell-rest" : "",
                  date === todayText ? "lite-calendar-cell-current-day" : "",
                  date === selectedDate ? "lite-calendar-cell-selected" : "",
                  daySchedule?.taskCount ? "" : "lite-calendar-cell-out"
                ]
                  .filter(Boolean)
                  .join(" ")}
                onClick={() => onSelectDate(date)}
              >
                <div className="schedule-calendar-cell-top">
                  <div className="lite-calendar-date">{date.slice(8)}</div>
                  <span
                    className={`schedule-calendar-shift-chip ${
                      isRest ? "schedule-calendar-shift-chip-rest" : ""
                    }`}
                  >
                    {shiftLabel}
                  </span>
                </div>

                {reason ? <div className="lite-holiday-tag">{reason}</div> : null}

                <div className="schedule-calendar-cell-body">
                  {!isRest ? (
                    <div className="schedule-calendar-kpi-row">
                      <div className="schedule-calendar-kpi-item">
                        <span>{"\u4efb\u52a1"}</span>
                        <strong>{taskCount}</strong>
                      </div>
                      <span className="schedule-calendar-kpi-split" aria-hidden="true">
                        /
                      </span>
                      <div className="schedule-calendar-kpi-item">
                        <span>{"\u8ba2\u5355"}</span>
                        <strong>{orderCount}</strong>
                      </div>
                    </div>
                  ) : (
                    <div className="schedule-calendar-rest-placeholder" aria-hidden="true" />
                  )}
                </div>

                {isRest ? (
                  <div className="lite-cal-mode-actions schedule-calendar-cell-actions schedule-calendar-cell-actions-rest">
                    <button
                      type="button"
                      data-testid={`schedule-calendar-set-day-${date}`}
                      className={`lite-cal-mode-btn ${dayModeButtonClass(effectiveMode)}`}
                      onClick={(event) => {
                        event.stopPropagation();
                        onSetDateMode(date, DATE_SHIFT_MODE.DAY);
                      }}
                    >
                      {"\u4e0a\u73ed"}
                    </button>
                    <button
                      type="button"
                      data-testid={`schedule-calendar-set-night-${date}`}
                      className={`lite-cal-mode-btn ${nightModeButtonClass(effectiveMode)}`}
                      onClick={(event) => {
                        event.stopPropagation();
                        onSetDateMode(date, DATE_SHIFT_MODE.NIGHT);
                      }}
                    >
                      {"\u591c\u73ed"}
                    </button>
                  </div>
                ) : (
                  <div className="lite-cal-mode-actions schedule-calendar-cell-actions">
                    <button
                      type="button"
                      data-testid={`schedule-calendar-set-rest-${date}`}
                      className={`lite-cal-mode-btn ${
                        effectiveMode === DATE_SHIFT_MODE.REST ? "schedule-calendar-mode-btn-active" : ""
                      }`}
                      onClick={(event) => {
                        event.stopPropagation();
                        onSetDateMode(date, DATE_SHIFT_MODE.REST);
                      }}
                    >
                      {"\u4f11\u606f"}
                    </button>
                    <button
                      type="button"
                      data-testid={`schedule-calendar-set-day-${date}`}
                      className={`lite-cal-mode-btn ${dayModeButtonClass(effectiveMode)}`}
                      onClick={(event) => {
                        event.stopPropagation();
                        onSetDateMode(date, DATE_SHIFT_MODE.DAY);
                      }}
                    >
                      {"\u4e0a\u73ed"}
                    </button>
                    <button
                      type="button"
                      data-testid={`schedule-calendar-set-night-${date}`}
                      className={`lite-cal-mode-btn ${nightModeButtonClass(effectiveMode)}`}
                      onClick={(event) => {
                        event.stopPropagation();
                        onSetDateMode(date, DATE_SHIFT_MODE.NIGHT);
                      }}
                    >
                      {"\u591c\u73ed"}
                    </button>
                  </div>
                )}

                {!isRest && visibleOrderNos.length > 0 ? (
                  <div className="schedule-calendar-order-list" aria-label="\u6b63\u5728\u6392\u4ea7\u8ba2\u5355">
                    {visibleOrderNos.map((orderNo) => (
                      <div key={`${date}-${orderNo}`} className="schedule-calendar-order-item" title={orderNo}>
                        {orderNo}
                      </div>
                    ))}
                    {hiddenOrderCount > 0 ? (
                      <div
                        className="schedule-calendar-order-more"
                        title={`\u8fd8\u6709 ${hiddenOrderCount} \u4e2a\u8ba2\u5355`}
                      >
                        +{hiddenOrderCount}
                      </div>
                    ) : null}
                  </div>
                ) : null}
              </article>
            );
          })
        )}
      </div>
    </div>
  );
}
