import { ScheduleCalendarDetailPanel } from "../features/schedule-calendar/components/ScheduleCalendarDetailPanel";
import { ScheduleCalendarGrid } from "../features/schedule-calendar/components/ScheduleCalendarGrid";
import { ScheduleCalendarMonthToolbar } from "../features/schedule-calendar/components/ScheduleCalendarMonthToolbar";
import { ScheduleCalendarSettingsPanel } from "../features/schedule-calendar/components/ScheduleCalendarSettingsPanel";
import { useScheduleCalendarController } from "../features/schedule-calendar/useScheduleCalendarController";

export default function ScheduleCalendarPage() {
  const {
    selectedVersionNo,
    setSelectedVersionNo,
    skipStatutoryHolidays,
    setSkipStatutoryHolidays,
    weekendRestMode,
    setWeekendRestMode,
    dateShiftModeByDate,
    calendarMonth,
    simulatedCurrentDate,
    selectedDate,
    setSelectedDate,
    loadingInit,
    loadingTasks,
    savingRules,
    replanning,
    generatingDraft,
    publishing,
    advancingSimulationDay,
    resettingSimulation,
    activeWorkshopCode,
    setActiveWorkshopCode,
    strategyCode,
    setStrategyCode,
    message,
    error,

    topology,
    dayScheduleByDate,
    calendarWeeks,
    selectedDaySchedule,
    workshopTabs,
    activeWorkshop,
    versionOptions,
    canPublishSelected,
    selectedDateMode,
    selectedDateMaterialEstimateRows,
    strategyOptions,
    loadingMaterialEstimate,
    materialEstimateError,

    refreshVersionsAndConfig,
    moveCalendarMonth,
    selectCalendarMonth,
    restReasonForDate,
    setDateMode,
    saveAndReplan,
    generateDraftVersion,
    publishSelectedDraft,
    advanceSimulationOneDay,
    resetManualSimulation
  } = useScheduleCalendarController();

  return (
    <section className="schedule-calendar-page">
      <div className="schedule-calendar-layout">
        <div className="panel schedule-calendar-left">
          <div className="panel-head">
            <h3>月历视图</h3>
            <ScheduleCalendarMonthToolbar
              calendarMonth={calendarMonth}
              loadingInit={loadingInit}
              loadingTasks={loadingTasks}
              onMoveCalendarMonth={moveCalendarMonth}
              onSelectCalendarMonth={selectCalendarMonth}
            />
          </div>

          <ScheduleCalendarGrid
            calendarWeeks={calendarWeeks}
            dayScheduleByDate={dayScheduleByDate}
            currentDate={simulatedCurrentDate}
            selectedDate={selectedDate}
            skipStatutoryHolidays={skipStatutoryHolidays}
            weekendRestMode={weekendRestMode}
            dateShiftModeByDate={dateShiftModeByDate}
            onSelectDate={setSelectedDate}
            onSetDateMode={setDateMode}
            restReasonForDate={restReasonForDate}
          />
        </div>

        <div className="schedule-calendar-right">
          <ScheduleCalendarSettingsPanel
            loadingInit={loadingInit}
            selectedVersionNo={selectedVersionNo}
            versionOptions={versionOptions}
            onChangeVersion={setSelectedVersionNo}
            onRefreshVersionsAndConfig={() => refreshVersionsAndConfig(true)}
            strategyCode={strategyCode}
            strategyOptions={strategyOptions}
            onChangeStrategy={setStrategyCode}
            onGenerateDraftVersion={generateDraftVersion}
            onPublishSelectedDraft={publishSelectedDraft}
            skipStatutoryHolidays={skipStatutoryHolidays}
            onToggleSkipStatutoryHolidays={setSkipStatutoryHolidays}
            weekendRestMode={weekendRestMode}
            onChangeWeekendRestMode={setWeekendRestMode}
            message={message}
            error={error}
            topology={topology}
            savingRules={savingRules}
            replanning={replanning}
            generatingDraft={generatingDraft}
            publishing={publishing}
            advancingSimulationDay={advancingSimulationDay}
            resettingSimulation={resettingSimulation}
            canPublishSelected={canPublishSelected}
            onSave={saveAndReplan}
            onAdvanceSimulationOneDay={advanceSimulationOneDay}
            onResetManualSimulation={resetManualSimulation}
          />

          <ScheduleCalendarDetailPanel
            selectedDate={selectedDate}
            selectedDateMode={selectedDateMode}
            selectedDaySchedule={selectedDaySchedule}
            workshopTabs={workshopTabs}
            activeWorkshop={activeWorkshop}
            activeWorkshopCode={activeWorkshopCode}
            onSelectWorkshop={setActiveWorkshopCode}
            materialEstimateRows={selectedDateMaterialEstimateRows}
            loadingMaterialEstimate={loadingMaterialEstimate}
            materialEstimateError={materialEstimateError}
          />
        </div>
      </div>
    </section>
  );
}
