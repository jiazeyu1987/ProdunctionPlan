"""ProductionPlan FastAPI application package."""
